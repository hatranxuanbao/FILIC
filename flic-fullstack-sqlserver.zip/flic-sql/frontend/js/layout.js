// ===== SHARED LAYOUT GENERATOR =====
function renderLayout(pageId, pageTitle, contentHTML) {
  const logo = '../src/assets/bb21610d5fa0b1d8a65b7ce9827d83c61bf7a2c5.png';

  const navItems = [
    { id: 'home',      label: 'Trang chủ',          href: 'dashboard.html',        icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>' },
    { id: 'favorites', label: 'Danh sách yêu thích', href: 'favorites.html',        icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>' },
  ];
  const mgmtItems = [
    { id: 'form-management',       label: 'Quản lý form mẫu',   href: 'form-management.html',    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>' },
    { id: 'approval-management',   label: 'Quản lý phê duyệt',  href: 'approval.html',           icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/><polyline points="16 11 18 13 22 9"/></svg>' },
    { id: 'reports-statistics',    label: 'Báo cáo - thống kê', href: 'reports.html',            icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>' },
    { id: 'feedback-management',   label: 'Quản lý phản hồi',   href: 'feedback.html',           icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>' },
    { id: 'staff-management',      label: 'Quản lý nhân viên',  href: 'staff.html',              icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>' },
    { id: 'notification-management', label: 'Quản lý thông báo', href: 'notifications-mgmt.html', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>' },
  ];

  function navItem(item) {
    const active = item.id === pageId ? ' active' : '';
    return `<a href="${item.href}" class="sidebar-item${active}" data-page="${item.id}">${item.icon}<span>${item.label}</span></a>`;
  }

  return `
  <div class="app-layout">
    <aside class="sidebar">
      <div class="sidebar-logo">
        <img src="${logo}" alt="FLIC Logo" onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
        <div style="display:none;font-size:20px;font-weight:700;color:#38bdf8">FLIC</div>
        <div class="sidebar-tagline">Trung Tâm Ngoại Ngữ - Tin Học</div>
      </div>
      <nav class="sidebar-nav">
        ${navItems.map(navItem).join('')}
        <div class="sidebar-section-label">Quản lý</div>
        ${mgmtItems.map(navItem).join('')}
      </nav>
      <div class="sidebar-bottom">
        <a href="settings.html" class="sidebar-item${pageId === 'settings' ? ' active' : ''}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
          <span>Cài đặt</span>
        </a>
        <button onclick="logout()" class="sidebar-item logout" style="width:100%">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          <span>Đăng xuất</span>
        </button>
      </div>
    </aside>

    <div class="main-content">
      <header class="header">
        <div style="display:flex;align-items:center;gap:12px">
          <button onclick="window.location.href='dashboard.html'" style="display:flex;flex-direction:column;gap:5px;width:36px;height:36px;padding:8px;border-radius:8px;cursor:pointer;background:transparent;border:none;transition:background .15s" onmouseenter="this.style.background='var(--gray-100)'" onmouseleave="this.style.background='transparent'">
            <span style="display:block;height:2px;width:20px;background:var(--gray-600);border-radius:2px"></span>
            <span style="display:block;height:2px;width:14px;background:var(--gray-600);border-radius:2px"></span>
            <span style="display:block;height:2px;width:17px;background:var(--gray-600);border-radius:2px"></span>
          </button>
        </div>
        <div class="header-actions">
          <button class="icon-btn" onclick="openPanel('notif-panel')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
          </button>
          <button class="icon-btn" onclick="openModal('help-modal')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          </button>
          <div class="user-chip">
            <div class="user-avatar">A</div>
            <span class="user-name">admin</span>
          </div>
        </div>
      </header>
      <main class="page-body">
        ${contentHTML}
      </main>
    </div>
  </div>

  <!-- Notifications Panel -->
  <div class="panel-overlay" id="notif-panel" onclick="closePanel('notif-panel')">
    <div class="panel" onclick="event.stopPropagation()">
      <div class="panel-header">
        <span class="panel-title">Thông báo</span>
        <button class="icon-btn close-btn" onclick="closePanel('notif-panel')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <div class="panel-body">
        <div class="notif-item unread">
          <div class="notif-icon" style="background:#dbeafe"><svg viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="2" width="18" height="18"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
          <div><div class="notif-title">Form mới được tạo</div><div class="notif-msg">Trần Thị B đã tạo form "Khảo sát mức độ hài lòng"</div><div class="notif-time">5 phút trước</div></div>
        </div>
        <div class="notif-item unread">
          <div class="notif-icon" style="background:#dcfce7"><svg viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="2" width="18" height="18"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></div>
          <div><div class="notif-title">Phê duyệt thành công</div><div class="notif-msg">Form "Đăng ký khóa học Tiếng Anh" đã được phê duyệt</div><div class="notif-time">1 giờ trước</div></div>
        </div>
        <div class="notif-item">
          <div class="notif-icon" style="background:#fef9c3"><svg viewBox="0 0 24 24" fill="none" stroke="#ca8a04" stroke-width="2" width="18" height="18"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></div>
          <div><div class="notif-title">Cần xem xét</div><div class="notif-msg">Có 3 form đang chờ phê duyệt</div><div class="notif-time">3 giờ trước</div></div>
        </div>
      </div>
      <div style="padding:16px;border-top:1px solid var(--gray-200)">
        <a href="notifications-mgmt.html" class="btn btn-outline btn-full">Xem tất cả thông báo</a>
      </div>
    </div>
  </div>

  <!-- Help Modal -->
  <div class="modal-overlay" id="help-modal">
    <div class="modal" style="max-width:540px" onclick="event.stopPropagation()">
      <div class="modal-header">
        <span class="modal-title">Trung tâm hỗ trợ</span>
        <button class="icon-btn close-btn" onclick="closeModal('help-modal')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
      <div class="modal-body">
        <div class="input-wrap" style="margin-bottom:16px">
          <div class="input-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>
          <input type="text" class="input" placeholder="Tìm kiếm hướng dẫn...">
        </div>
        <div class="grid-2" style="gap:12px">
          <div class="card" style="padding:16px;cursor:pointer" onclick="showToast('Đang mở hướng dẫn...')"><div style="width:40px;height:40px;border-radius:8px;background:#e0f2fe;display:flex;align-items:center;justify-content:center;margin-bottom:10px"><svg viewBox="0 0 24 24" fill="none" stroke="#0ea5e9" stroke-width="2" width="20" height="20"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div><div style="font-weight:600;font-size:14px">Quản lý Form</div><div style="font-size:12px;color:var(--gray-500);margin-top:4px">Hướng dẫn tạo và quản lý biểu mẫu</div></div>
          <div class="card" style="padding:16px;cursor:pointer" onclick="showToast('Đang mở hướng dẫn...')"><div style="width:40px;height:40px;border-radius:8px;background:#f3e8ff;display:flex;align-items:center;justify-content:center;margin-bottom:10px"><svg viewBox="0 0 24 24" fill="none" stroke="#8b5cf6" stroke-width="2" width="20" height="20"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg></div><div style="font-weight:600;font-size:14px">Quản lý Nhân viên</div><div style="font-size:12px;color:var(--gray-500);margin-top:4px">Phân quyền và quản lý người dùng</div></div>
        </div>
      </div>
    </div>
  </div>

  <button class="help-fab" onclick="openModal('help-modal')">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
  </button>
  <div id="toast-container"></div>
  `;
}

function logout() {
  window.location.href = '../index.html';
}

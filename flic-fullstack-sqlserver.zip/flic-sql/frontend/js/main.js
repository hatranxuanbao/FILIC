// ===== SHARED SVG ICONS =====
const IC = {
  filter:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>`,
  chevDown:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="6 9 12 15 18 9"/></svg>`,
  download:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
  downloadSm:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
  close:     `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  search:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  plus:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,
  eye:       `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`,
  edit:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`,
  trashSm:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg>`,
  dots:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>`,
  check:     `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M20 6L9 17l-5-5"/></svg>`,
  reject:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  save:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/></svg>`,
};

// ===== SHARED HTML BUILDERS =====

// Export dropdown (Xuất Excel / PDF / CSV)
function exportDropdown(wrapId, menuId) {
  const items = ['Excel','PDF','CSV'].map(t =>
    `<div class="export-drop-item" onclick="showToast('Đang xuất ${t}...','success');document.getElementById('${menuId}').classList.remove('open')">${IC.downloadSm}Xuất ${t}</div>`
  ).join('');
  return `
  <div style="position:relative" id="${wrapId}">
    <button class="btn btn-outline" onclick="document.getElementById('${menuId}').classList.toggle('open')">
      ${IC.download}Xuất danh sách${IC.chevDown}
    </button>
    <div class="export-drop-menu" id="${menuId}">${items}</div>
  </div>`;
}

// Advanced filter panel
function filterPanel(panelId, fields) {
  const fieldHtml = fields.map(f => `
    <div>
      <label style="font-size:12.5px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:5px">${f.label}</label>
      ${f.type === 'date'
        ? `<input type="date" class="input" style="width:100%">`
        : `<select id="${f.id||''}" class="input" style="width:100%">${f.opts.map(o=>
            typeof o==='string' ? `<option>${o}</option>` : `<option value="${o.v}">${o.l}</option>`
          ).join('')}</select>`
      }
    </div>`).join('');
  return `
  <div id="${panelId}" style="display:none;margin-bottom:16px">
    <div style="background:#fff;border:1px solid var(--gray-200);border-radius:var(--radius-lg);padding:20px;box-shadow:var(--shadow-sm)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <span style="font-size:15px;font-weight:700">Bộ lọc nâng cao</span>
        <button class="icon-btn" onclick="document.getElementById('${panelId}').style.display='none'">${IC.close}</button>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:14px">${fieldHtml}</div>
      <div style="display:flex;gap:10px">
        <button class="btn btn-primary" onclick="applyFilter()">Áp dụng bộ lọc</button>
        <button class="btn btn-outline" onclick="resetFilter()">Xóa bộ lọc</button>
      </div>
    </div>
  </div>`;
}

// Stat card
function statCard(label, value, color, bg, iconPath, extra='') {
  return `<div class="card stat-card" style="padding:20px">
    <div class="stat-header">
      <div><div class="stat-label">${label}</div><div class="stat-value" style="color:${color}">${value}</div></div>
      ${bg ? `<div class="stat-icon" style="background:${bg}"><svg viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" width="22" height="22">${iconPath}</svg></div>` : ''}
    </div>${extra}</div>`;
}

// Close dropdown on outside click
function outsideClick(wrapId, menuId) {
  document.addEventListener('click', e => {
    if (!e.target.closest('#' + wrapId))
      document.getElementById(menuId)?.classList.remove('open');
  });
}

// ===== TOAST =====
function showToast(message, type = 'default') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icons = {
    success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="16" height="16"><path d="M20 6L9 17l-5-5"/></svg>',
    error:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
    warning: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
    default: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
  };
  toast.innerHTML = (icons[type] || icons.default) + `<span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'fadeOut 0.3s ease forwards';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ===== MODAL =====
function openModal(id) {
  const o = document.getElementById(id);
  if (o) { o.classList.add('open'); document.body.style.overflow = 'hidden'; }
}
function closeModal(id) {
  const o = document.getElementById(id);
  if (o) { o.classList.remove('open'); document.body.style.overflow = ''; }
}
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
    document.body.style.overflow = '';
  }
});

// ===== PANEL =====
function openPanel(id) {
  const o = document.getElementById(id);
  if (o) { o.classList.add('open'); document.body.style.overflow = 'hidden'; }
}
function closePanel(id) {
  const o = document.getElementById(id);
  if (o) { o.classList.remove('open'); document.body.style.overflow = ''; }
}
document.addEventListener('click', e => {
  if (e.target.classList.contains('panel-overlay')) {
    e.target.classList.remove('open');
    document.body.style.overflow = '';
  }
});

// ===== TABS =====
function initTabs(containerSelector) {
  const containers = document.querySelectorAll(containerSelector || '[data-tabs]');
  containers.forEach(container => {
    const buttons = container.querySelectorAll('.tab-btn');
    const contents = container.querySelectorAll('.tab-content');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        contents.forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        const target = btn.dataset.tab;
        const content = container.querySelector(`[data-tab-content="${target}"]`);
        if (content) content.classList.add('active');
      });
    });
  });
}

// ===== DROPDOWN =====
function initDropdowns() {
  document.addEventListener('click', e => {
    const trigger = e.target.closest('[data-dropdown-trigger]');
    if (trigger) {
      e.stopPropagation();
      const targetId = trigger.dataset.dropdownTrigger;
      const menu = document.getElementById(targetId);
      if (menu) {
        document.querySelectorAll('.dropdown-menu.open').forEach(m => { if (m !== menu) m.classList.remove('open'); });
        menu.classList.toggle('open');
      }
      return;
    }
    document.querySelectorAll('.dropdown-menu.open').forEach(m => m.classList.remove('open'));
  });
}

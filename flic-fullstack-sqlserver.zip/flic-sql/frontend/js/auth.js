// frontend/js/auth.js
// Xử lý đăng nhập thật với API

async function handleLogin(e) {
  e.preventDefault();
  const btn      = document.getElementById('login-btn');
  const spinner  = document.getElementById('spinner');
  const btnText  = document.getElementById('btn-text');

  const username = document.getElementById('inp-user').value.trim();
  const password = document.getElementById('inp-pass').value;

  if (!username || !password) {
    showToastLogin('Vui lòng nhập đầy đủ thông tin!', 'error');
    return;
  }

  btn.disabled         = true;
  spinner.style.display = 'block';
  btnText.textContent  = 'ĐANG XỬ LÝ...';

  try {
    const res = await fetch('http://localhost:3000/api/auth/login', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ username, password }),
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.error || 'Đăng nhập thất bại');

    // Lưu token và user vào localStorage
    localStorage.setItem('flic_token', data.token);
    localStorage.setItem('flic_user',  JSON.stringify(data.user));

    // Chuyển sang dashboard
    window.location.href = 'pages/dashboard.html';

  } catch (err) {
    showToastLogin(err.message, 'error');
    btn.disabled          = false;
    spinner.style.display = 'none';
    btnText.textContent   = 'ĐĂNG NHẬP';
  }
}

// Toast đơn giản cho trang login (chưa load main.js)
function showToastLogin(msg, type = 'error') {
  let toast = document.getElementById('login-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'login-toast';
    toast.style.cssText = 'position:fixed;bottom:24px;right:24px;padding:12px 20px;border-radius:10px;font-size:14px;font-weight:600;z-index:9999;transition:opacity .3s';
    document.body.appendChild(toast);
  }
  toast.textContent   = msg;
  toast.style.background = type === 'error' ? '#ef4444' : '#10b981';
  toast.style.color      = '#fff';
  toast.style.opacity    = '1';
  setTimeout(() => { toast.style.opacity = '0'; }, 3000);
}

// Quên mật khẩu
async function handleForgotPassword(e) {
  e.preventDefault();
  const email = document.getElementById('inp-forgot-email')?.value?.trim();
  if (!email) { showToastLogin('Vui lòng nhập email!'); return; }

  try {
    const res  = await fetch('http://localhost:3000/api/auth/forgot-password', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ email }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    showToastLogin(data.message, 'success');
  } catch (err) {
    showToastLogin(err.message);
  }
}

// Kiểm tra đã đăng nhập chưa (dùng ở tất cả trang con)
function checkAuth() {
  const token = localStorage.getItem('flic_token');
  const user  = localStorage.getItem('flic_user');
  if (!token || !user) {
    window.location.href = '../index.html';
    return null;
  }
  return JSON.parse(user);
}

// Đăng xuất
function logout() {
  localStorage.removeItem('flic_token');
  localStorage.removeItem('flic_user');
  window.location.href = '../index.html';
}

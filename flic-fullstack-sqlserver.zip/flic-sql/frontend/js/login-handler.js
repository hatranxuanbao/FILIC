    function handleLogin(e) {
      e.preventDefault();
      const btn      = document.getElementById('login-btn');
      const spinner  = document.getElementById('spinner');
      const btnText  = document.getElementById('btn-text');
      const username = document.getElementById('inp-user').value.trim();
      const password = document.getElementById('inp-pass').value;

      if (!username || !password) {
        showErr('Vui lòng nhập tên đăng nhập và mật khẩu!');
        return;
      }

      btn.disabled = true;
      spinner.style.display = 'block';
      btnText.textContent   = 'ĐANG XỬ LÝ...';

      fetch('http://localhost:3000/api/auth/login', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ username, password }),
      })
      .then(r => r.json())
      .then(data => {
        if (data.error) throw new Error(data.error);

        // Lưu token và thông tin user
        localStorage.setItem('flic_token', data.token);
        localStorage.setItem('flic_user',  JSON.stringify(data.user));

        // Chuyển sang dashboard
        window.location.href = 'pages/dashboard.html';
      })
      .catch(err => {
        btn.disabled          = false;
        spinner.style.display = 'none';
        btnText.textContent   = 'ĐĂNG NHẬP';
        showErr(err.message || 'Sai tài khoản hoặc mật khẩu!');
      });
    }

    function showErr(msg) {
      let el = document.getElementById('login-error');
      if (!el) {
        el = document.createElement('div');
        el.id = 'login-error';
        el.style.cssText = 'background:#fee2e2;color:#dc2626;border-radius:8px;padding:10px 14px;font-size:13px;margin-top:12px;text-align:center';
        document.querySelector('.login-card').appendChild(el);
      }
      el.textContent = msg;
      el.style.display = 'block';
      setTimeout(() => { el.style.display = 'none'; }, 4000);
    }

// frontend/js/api.js
// Kết nối Frontend → Backend Express API

const API_BASE = 'http://localhost:3000/api';

// ── Lấy token từ localStorage ────────────────────────────────────────
function getToken() {
  return localStorage.getItem('flic_token') || '';
}

// ── Hàm fetch chung ──────────────────────────────────────────────────
async function apiFetch(path, options = {}) {
  try {
    const res = await fetch(API_BASE + path, {
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${getToken()}`,
        ...(options.headers || {}),
      },
      method: options.method || 'GET',
      body:   options.body ? JSON.stringify(options.body) : undefined,
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.error || 'Lỗi server');

    return data;
  } catch (err) {
    if (typeof showToast === 'function') showToast('Lỗi: ' + err.message, 'error');
    throw err;
  }
}

// ── API Object ───────────────────────────────────────────────────────
const api = {

  // AUTH ────────────────────────────────────────────────────────────
  login: (username, password) =>
    apiFetch('/auth/login', { method: 'POST', body: { username, password } }),

  register: (data) =>
    apiFetch('/auth/register', { method: 'POST', body: data }),

  getMe: () =>
    apiFetch('/auth/me'),

  forgotPassword: (email) =>
    apiFetch('/auth/forgot-password', { method: 'POST', body: { email } }),

  // DASHBOARD ───────────────────────────────────────────────────────
  stats: () =>
    apiFetch('/dashboard/stats'),

  // FORM MẪU ────────────────────────────────────────────────────────
  // Lấy danh sách: api.getForms({ search: '', danhmuc: 'Đăng ký', trangthai: 'active' })
  getForms: (params = {}) =>
    apiFetch('/forms?' + new URLSearchParams(params)),

  // Lấy 1 form: api.getForm('id')
  getForm: (id) =>
    apiFetch('/forms/' + id),

  // Tạo form mới
  createForm: (data) =>
    apiFetch('/forms', { method: 'POST', body: data }),

  // Cập nhật form
  updateForm: (id, data) =>
    apiFetch('/forms/' + id, { method: 'PUT', body: data }),

  // Xóa form
  deleteForm: (id) =>
    apiFetch('/forms/' + id, { method: 'DELETE' }),

  // Lấy phản hồi của form
  getFormResponses: (id) =>
    apiFetch('/forms/' + id + '/responses'),

  // PHẢN HỒI ────────────────────────────────────────────────────────
  // Lấy tất cả phản hồi
  getResponses: (params = {}) =>
    apiFetch('/responses?' + new URLSearchParams(params)),

  // Khách hàng gửi form (không cần token)
  submitForm: (data) =>
    fetch(API_BASE + '/responses/submit', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(data),
    }).then(r => r.json()),

  // Cập nhật trạng thái phản hồi
  updateResponse: (id, data) =>
    apiFetch('/responses/' + id, { method: 'PUT', body: data }),

  // Xóa phản hồi
  deleteResponse: (id) =>
    apiFetch('/responses/' + id, { method: 'DELETE' }),

  // NHÂN VIÊN ───────────────────────────────────────────────────────
  getUsers: (params = {}) =>
    apiFetch('/users?' + new URLSearchParams(params)),

  createUser: (data) =>
    apiFetch('/users', { method: 'POST', body: data }),

  updateUser: (id, data) =>
    apiFetch('/users/' + id, { method: 'PUT', body: data }),

  deleteUser: (id) =>
    apiFetch('/users/' + id, { method: 'DELETE' }),

  // Alias cũ (tương thích ngược)
  getTaiKhoan:    (p) => api.getUsers(p),
  createTaiKhoan: (d) => api.createUser(d),
  getFormMau:     (p) => api.getForms(p).then(r => r.forms || []),
  createFormMau:  (d) => api.createForm(d),
  getPhanHoi:     (p) => api.getResponses(p).then(r => r.responses || []),
};

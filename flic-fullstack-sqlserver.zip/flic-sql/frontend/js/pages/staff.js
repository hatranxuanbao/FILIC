const STAFF = [
  {id:'1',name:'Nguyễn Văn A',email:'nguyenvana@flic.edu.vn',phone:'0912345678',role:'admin',dept:'Quản lý hệ thống',status:'active',forms:48,last:'2 phút trước',seed:'a1',color:'#0ea5e9'},
  {id:'2',name:'Trần Thị B',email:'tranthib@flic.edu.vn',phone:'0923456789',role:'manager',dept:'Phòng Ngoại ngữ',status:'active',forms:32,last:'1 giờ trước',seed:'b2',color:'#8b5cf6'},
  {id:'3',name:'Lê Văn C',email:'levanc@flic.edu.vn',phone:'0934567890',role:'staff',dept:'Phòng Tin học',status:'active',forms:21,last:'3 giờ trước',seed:'c3',color:'#f97316'},
  {id:'4',name:'Phạm Thị D',email:'phamthid@flic.edu.vn',phone:'0945678901',role:'staff',dept:'Phòng Ngoại ngữ',status:'inactive',forms:15,last:'2 ngày trước',seed:'d4',color:'#ec4899'},
  {id:'5',name:'Hoàng Văn E',email:'hoangvane@flic.edu.vn',phone:'0956789012',role:'manager',dept:'Phòng Đào tạo',status:'active',forms:39,last:'5 phút trước',seed:'e5',color:'#10b981'},
  {id:'6',name:'Vũ Thị F',email:'vuthif@flic.edu.vn',phone:'0967890123',role:'staff',dept:'Phòng Tin học',status:'active',forms:28,last:'30 phút trước',seed:'f6',color:'#64748b'},
];

const roleBadge = r => r==='admin'?'<span class="badge badge-purple">Admin</span>':r==='manager'?'<span class="badge badge-blue">Quản lý</span>':'<span class="badge badge-gray">Nhân viên</span>';

document.getElementById('page-content').innerHTML = `
  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between">
    <div><h2 class="page-title">Quản lý nhân viên</h2><p class="page-sub">Quản lý thông tin và quyền hạn nhân viên</p></div>
    <div style="display:flex;gap:8px;align-items:center">
      <button class="btn btn-outline" onclick="document.getElementById('staff-fp').style.display=document.getElementById('staff-fp').style.display==='none'?'block':'none'">${IC.filter}Lọc</button>
      ${exportDropdown('staff-exp-wrap','staff-exp-menu')}
      <button class="btn btn-primary" onclick="openModal('add-staff-modal')">${IC.plus}Thêm nhân viên</button>
    </div>
  </div>

  <div class="grid-3" style="margin-bottom:20px">
    ${statCard('Tổng nhân viên',`<span id="stat-total">${STAFF.length}</span>`,'#0ea5e9','#e0f2fe','<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>')}
    ${statCard('Đang hoạt động',`<span id="stat-active" style="color:#10b981">${STAFF.filter(s=>s.status==='active').length}</span>`,'#10b981','#dcfce7','<path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>')}
    ${statCard('Không hoạt động',`<span id="stat-inactive" style="color:#64748b">${STAFF.filter(s=>s.status==='inactive').length}</span>`,'#64748b','#f1f5f9','<path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="17" y1="8" x2="23" y2="14"/><line x1="23" y1="8" x2="17" y2="14"/>')}
  </div>

  <div class="card card-body" style="margin-bottom:20px">
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <div class="input-wrap" style="flex:1;min-width:200px">
        <div class="input-icon">${IC.search}</div>
        <input type="text" class="input" placeholder="Tìm kiếm nhân viên..." oninput="filterStaff(this.value)">
      </div>
      <select class="input" style="width:auto" onchange="filterByRole(this.value)">
        <option value="all">Tất cả vai trò</option><option value="admin">Admin</option><option value="manager">Quản lý</option><option value="staff">Nhân viên</option>
      </select>
    </div>
  </div>

  ${filterPanel('staff-fp', [
    {label:'Vai trò', opts:['Tất cả vai trò','Admin','Quản lý','Nhân viên']},
    {label:'Trạng thái', opts:['Tất cả','Hoạt động','Không hoạt động']},
    {label:'Phòng ban', opts:['Tất cả phòng ban','Phòng Ngoại ngữ','Phòng Tin học','Phòng Đào tạo']},
    {label:'Từ ngày', type:'date'},
  ])}

  <div class="grid-3" id="staff-grid"></div>

  <!-- Add Staff Modal -->
  <div class="modal-overlay" id="add-staff-modal">
    <div class="modal" onclick="event.stopPropagation()" style="max-width:580px">
      <div class="modal-header">
        <div><div class="modal-title">Thêm nhân viên mới</div><div style="font-size:12.5px;color:var(--gray-400);margin-top:2px">Tạo tài khoản nhân viên mới cho hệ thống</div></div>
        <button class="icon-btn close-btn" onclick="closeModal('add-staff-modal')">${IC.close}</button>
      </div>
      <div class="modal-body" style="max-height:72vh;overflow-y:auto">
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:var(--radius);padding:12px 14px;margin-bottom:14px;font-size:13px;color:#1e40af;line-height:1.5">
          Nhân viên mới sẽ nhận email hướng dẫn kích hoạt tài khoản và thiết lập mật khẩu lần đầu.
        </div>
        <div style="border:1px solid var(--gray-200);border-radius:var(--radius-lg);padding:20px;margin-bottom:14px">
          <div style="font-size:15px;font-weight:700;color:var(--sky);margin-bottom:16px">Thông tin cá nhân</div>
          <div class="form-group"><label class="form-label">Họ và tên <span style="color:var(--red)">*</span></label><input type="text" class="input" id="as-name" placeholder="VD: Nguyễn Văn A"></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div class="form-group" style="margin-bottom:0"><label class="form-label">Email <span style="color:var(--red)">*</span></label><input type="email" class="input" id="as-email" placeholder="name@flic.edu.vn"></div>
            <div class="form-group" style="margin-bottom:0"><label class="form-label">Số điện thoại</label><input type="tel" class="input" id="as-phone" placeholder="0912345678"></div>
          </div>
        </div>
        <div style="border:1px solid var(--gray-200);border-radius:var(--radius-lg);padding:20px;margin-bottom:14px">
          <div style="font-size:15px;font-weight:700;color:#0284c7;margin-bottom:16px">Thông tin công việc</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
            <div><label class="form-label">Vai trò <span style="color:var(--red)">*</span></label><select class="input" style="width:100%" id="as-role"><option value="staff">Nhân viên</option><option value="manager">Quản lý</option><option value="admin">Admin</option></select></div>
            <div><label class="form-label">Trạng thái</label><select class="input" style="width:100%" id="as-status"><option value="active">Hoạt động</option><option value="inactive">Không hoạt động</option></select></div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div><label class="form-label">Mật khẩu <span style="color:var(--red)">*</span></label><input type="password" class="input" id="as-pw" placeholder="Nhập mật khẩu"></div>
            <div><label class="form-label">Nhập lại mật khẩu <span style="color:var(--red)">*</span></label><input type="password" class="input" id="as-pw2" placeholder="Xác nhận mật khẩu"></div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline" onclick="closeModal('add-staff-modal')">Hủy bỏ</button>
        <button class="btn btn-outline" style="color:#7c3aed;border-color:#7c3aed" onclick="openModal('permission-modal')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>Phân quyền
        </button>
        <button class="btn btn-primary" onclick="saveAddStaff()">${IC.plus}Thêm nhân viên</button>
      </div>
    </div>
  </div>

  <!-- Permission Modal -->
  <div class="modal-overlay" id="permission-modal">
    <div class="modal" onclick="event.stopPropagation()" style="max-width:500px">
      <div class="modal-header">
        <div>
          <div class="modal-title">Phân quyền nhân viên</div>
          <div style="font-size:12.5px;color:var(--gray-400);margin-top:2px">Chọn các quyền phù hợp với vai trò</div>
        </div>
        <button class="icon-btn close-btn" onclick="closeModal('permission-modal')">${IC.close}</button>
      </div>
      <div class="modal-body">
        ${[
          { group: 'Quản lý biểu mẫu', color: '#0ea5e9', bg: '#e0f2fe', perms: [
            {id:'p-view-form',   label:'Xem danh sách form',     checked: true},
            {id:'p-create-form', label:'Tạo form mới',            checked: false},
            {id:'p-edit-form',   label:'Chỉnh sửa form',         checked: false},
            {id:'p-delete-form', label:'Xóa form',               checked: false},
          ]},
          { group: 'Phê duyệt', color: '#10b981', bg: '#dcfce7', perms: [
            {id:'p-view-appr',   label:'Xem yêu cầu phê duyệt',  checked: true},
            {id:'p-approve',     label:'Phê duyệt / Từ chối',    checked: false},
          ]},
          { group: 'Báo cáo & Thống kê', color: '#8b5cf6', bg: '#f3e8ff', perms: [
            {id:'p-view-report', label:'Xem báo cáo',            checked: true},
            {id:'p-export',      label:'Xuất dữ liệu',           checked: false},
          ]},
          { group: 'Quản lý nhân viên', color: '#f97316', bg: '#ffedd5', perms: [
            {id:'p-view-staff',  label:'Xem danh sách nhân viên',checked: true},
            {id:'p-manage-staff',label:'Thêm / Sửa / Xóa nhân viên', checked: false},
          ]},
          { group: 'Thông báo', color: '#ec4899', bg: '#fce7f3', perms: [
            {id:'p-view-notif',  label:'Xem thông báo',          checked: true},
            {id:'p-send-notif',  label:'Tạo & Gửi thông báo',    checked: false},
          ]},
        ].map(g => `
          <div style="margin-bottom:18px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
              <span style="width:10px;height:10px;border-radius:50%;background:${g.color};display:inline-block"></span>
              <span style="font-size:13.5px;font-weight:700;color:var(--gray-800)">${g.group}</span>
            </div>
            <div style="background:${g.bg}30;border:1px solid ${g.color}30;border-radius:var(--radius-lg);padding:12px 16px;display:flex;flex-direction:column;gap:10px">
              ${g.perms.map(p => `
                <label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-size:13.5px;color:var(--gray-700)">
                  <input type="checkbox" id="${p.id}" ${p.checked?'checked':''} style="width:16px;height:16px;accent-color:${g.color};cursor:pointer">
                  ${p.label}
                </label>`).join('')}
            </div>
          </div>`).join('')}
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline" onclick="closeModal('permission-modal')">Hủy</button>
        <button class="btn btn-primary" onclick="closeModal('permission-modal');showToast('Đã lưu phân quyền!','success')">
          ${IC.save}Lưu phân quyền
        </button>
      </div>
    </div>
  </div>

  <!-- Staff Detail Modal -->
  <div class="modal-overlay" id="staff-detail-modal">
    <div class="modal" style="max-width:500px" onclick="event.stopPropagation()">
      <div class="modal-header">
        <div>
          <div class="modal-title">Chi tiết nhân viên</div>
          <div style="font-size:12.5px;color:var(--gray-400);margin-top:2px">Thông tin chi tiết về nhân viên</div>
        </div>
        <button class="icon-btn close-btn" onclick="closeModal('staff-detail-modal')">${IC.close}</button>
      </div>
      <div class="modal-body">
        <div style="display:flex;align-items:center;gap:16px;margin-bottom:20px;padding-bottom:20px;border-bottom:1px solid var(--gray-100)">
          <img id="sd-avatar" src="" style="width:72px;height:72px;border-radius:50%;border:3px solid #e0f2fe;object-fit:cover">
          <div>
            <div id="sd-name" style="font-size:18px;font-weight:800;color:var(--gray-900);margin-bottom:2px"></div>
            <div id="sd-dept" style="font-size:13px;color:var(--gray-500);margin-bottom:8px"></div>
            <div style="display:flex;align-items:center;gap:8px">
              <span id="sd-role-badge"></span>
              <span id="sd-status-dot" style="width:8px;height:8px;border-radius:50%;display:inline-block"></span>
              <span id="sd-status-text" style="font-size:13px;font-weight:500"></span>
            </div>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px">
          <div>
            <div style="display:flex;align-items:center;gap:6px;color:var(--gray-400);margin-bottom:4px;font-size:12px">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>Email
            </div>
            <div id="sd-email" style="font-size:14px;font-weight:600;color:var(--gray-800)"></div>
          </div>
          <div>
            <div style="display:flex;align-items:center;gap:6px;color:var(--gray-400);margin-bottom:4px;font-size:12px">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 014.69 13.5a19.79 19.79 0 01-3.07-8.67A2 2 0 013.6 2.68h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>Số điện thoại
            </div>
            <div id="sd-phone" style="font-size:14px;font-weight:600;color:var(--gray-800)"></div>
          </div>
          <div>
            <div style="display:flex;align-items:center;gap:6px;color:var(--gray-400);margin-bottom:4px;font-size:12px">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Vai trò
            </div>
            <div id="sd-role-text" style="font-size:14px;font-weight:600;color:var(--gray-800)"></div>
          </div>
          <div>
            <div style="display:flex;align-items:center;gap:6px;color:var(--gray-400);margin-bottom:4px;font-size:12px">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>Phòng ban
            </div>
            <div id="sd-dept2" style="font-size:14px;font-weight:600;color:var(--gray-800)"></div>
          </div>
          <div>
            <div style="display:flex;align-items:center;gap:6px;color:var(--gray-400);margin-bottom:4px;font-size:12px">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Form đã tạo
            </div>
            <div id="sd-forms" style="font-size:14px;font-weight:600;color:var(--gray-800)"></div>
          </div>
          <div>
            <div style="display:flex;align-items:center;gap:6px;color:var(--gray-400);margin-bottom:4px;font-size:12px">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>Hoạt động cuối
            </div>
            <div id="sd-last" style="font-size:14px;font-weight:600;color:var(--gray-800)"></div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline" onclick="closeModal('staff-detail-modal')">Đóng</button>
        <button class="btn btn-primary" onclick="closeModal('staff-detail-modal');openStaffEdit(activeStaffId)">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>Chỉnh sửa
        </button>
      </div>
    </div>
  </div>

  <!-- Staff Edit Modal -->
  <div class="modal-overlay" id="staff-edit-modal">
    <div class="modal" style="max-width:500px" onclick="event.stopPropagation()">
      <div class="modal-header">
        <div>
          <div class="modal-title">Chỉnh sửa thông tin nhân viên</div>
          <div style="font-size:12.5px;color:var(--gray-400);margin-top:2px">Cập nhật thông tin và quyền hạn nhân viên</div>
        </div>
        <button class="icon-btn close-btn" onclick="closeModal('staff-edit-modal')">${IC.close}</button>
      </div>
      <div class="modal-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div class="form-group" style="margin:0">
            <label class="form-label">Họ và tên <span style="color:var(--red)">*</span></label>
            <input type="text" class="input" id="se-name" placeholder="Nguyễn Văn A">
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Email <span style="color:var(--red)">*</span></label>
            <input type="email" class="input" id="se-email" placeholder="name@flic.edu.vn">
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Số điện thoại <span style="color:var(--red)">*</span></label>
            <input type="tel" class="input" id="se-phone" placeholder="0912345678">
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Vai trò <span style="color:var(--red)">*</span></label>
            <select class="input" id="se-role">
              <option value="admin">Quản trị viên</option>
              <option value="manager">Quản lý</option>
              <option value="staff">Nhân viên</option>
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Mật khẩu mới</label>
            <input type="password" class="input" id="se-pw" placeholder="Để trống nếu không đổi">
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Trạng thái <span style="color:var(--red)">*</span></label>
            <select class="input" id="se-status">
              <option value="active">Hoạt động</option>
              <option value="inactive">Không hoạt động</option>
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline" onclick="closeModal('staff-edit-modal')">Hủy</button>
        <button class="btn btn-primary" onclick="saveStaffEdit()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>Lưu thay đổi
        </button>
      </div>
    </div>
  </div>


  <!-- Delete Staff Modal -->
  <div class="modal-overlay" id="staff-delete-modal">
    <div class="modal" style="max-width:420px" onclick="event.stopPropagation()">
      <div class="modal-header">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:36px;height:36px;border-radius:50%;background:#fee2e2;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <svg viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2" width="18" height="18"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          </div>
          <span class="modal-title">Xác nhận xóa</span>
        </div>
        <button class="icon-btn close-btn" onclick="closeModal('staff-delete-modal')">${IC.close}</button>
      </div>
      <div class="modal-body">
        <p style="color:var(--gray-700);margin:0 0 14px">Bạn có chắc muốn xóa nhân viên này?</p>
        <div style="background:var(--gray-50);border-radius:var(--radius);padding:12px;display:flex;align-items:center;gap:12px">
          <div id="sdel-avatar" class="avatar-initials" style="background:#0ea5e9;font-size:13px;width:40px;height:40px;flex-shrink:0"></div>
          <div>
            <div id="sdel-name" style="font-weight:700;font-size:14px"></div>
            <div id="sdel-dept" style="font-size:12px;color:var(--gray-500)"></div>
          </div>
        </div>
        <p style="font-size:12.5px;color:var(--gray-500);margin:12px 0 0">* Lưu ý: Hành động này không thể hoàn tác sau khi xác nhận.</p>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline" onclick="closeModal('staff-delete-modal')">Hủy</button>
        <button class="btn btn-primary" style="background:#dc2626;border-color:#dc2626" onclick="confirmDeleteStaff()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg>Xóa
        </button>
      </div>
    </div>
  </div>
`;

// ── Active staff tracker ──────────────────────────────────────────
let activeStaffId = null;

const roleLabel = r => r==='admin'?'Quản trị viên':r==='manager'?'Quản lý':'Nhân viên';

function openStaffDetail(id) {
  const s = STAFF.find(x=>x.id===id); if (!s) return;
  activeStaffId = id;
  document.getElementById('sd-avatar').src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${s.seed}`;
  document.getElementById('sd-name').textContent = s.name;
  document.getElementById('sd-dept').textContent = s.dept;
  document.getElementById('sd-role-badge').innerHTML = roleBadge(s.role);
  document.getElementById('sd-status-dot').style.background = s.status==='active'?'#22c55e':'#94a3b8';
  document.getElementById('sd-status-text').textContent = s.status==='active'?'Hoạt động':'Không hoạt động';
  document.getElementById('sd-status-text').style.color = s.status==='active'?'#16a34a':'#94a3b8';
  document.getElementById('sd-email').textContent = s.email;
  document.getElementById('sd-phone').textContent = s.phone;
  document.getElementById('sd-role-text').textContent = roleLabel(s.role);
  document.getElementById('sd-dept2').textContent = s.dept;
  document.getElementById('sd-forms').textContent = s.forms + ' form';
  document.getElementById('sd-last').textContent = s.last;
  document.getElementById('smenu-'+id)?.classList.remove('open');
  openModal('staff-detail-modal');
}

function openStaffEdit(id) {
  const s = STAFF.find(x=>x.id===id); if (!s) return;
  activeStaffId = id;
  document.getElementById('se-name').value  = s.name;
  document.getElementById('se-email').value = s.email;
  document.getElementById('se-phone').value = s.phone;
  document.getElementById('se-role').value  = s.role;
  document.getElementById('se-status').value = s.status;
  document.getElementById('se-pw').value = '';
  document.getElementById('smenu-'+id)?.classList.remove('open');
  closeModal('staff-detail-modal');
  openModal('staff-edit-modal');
}

function saveStaffEdit() {
  const name = document.getElementById('se-name').value.trim();
  const email = document.getElementById('se-email').value.trim();
  const phone = document.getElementById('se-phone').value.trim();
  if (!name)  { showToast('Vui lòng nhập họ và tên!','error'); return; }
  if (!email) { showToast('Vui lòng nhập email!','error'); return; }
  if (!phone) { showToast('Vui lòng nhập số điện thoại!','error'); return; }
  const s = STAFF.find(x=>x.id===activeStaffId); if (!s) return;
  s.name   = name;
  s.email  = email;
  s.phone  = phone;
  s.role   = document.getElementById('se-role').value;
  s.status = document.getElementById('se-status').value;
  closeModal('staff-edit-modal');
  renderStaff(STAFF);
  document.getElementById('stat-active').textContent = STAFF.filter(x=>x.status==='active').length;
  document.getElementById('stat-inactive').textContent = STAFF.filter(x=>x.status==='inactive').length;
  showToast('Đã cập nhật thông tin ' + name + '!','success');
}

function renderStaff(list) {
  document.getElementById('staff-grid').innerHTML = list.map(s=>`
    <div style="background:#fff;border-radius:var(--radius-lg);border:1px solid var(--gray-200);overflow:hidden;box-shadow:var(--shadow-sm)">
      <div style="height:72px;background:linear-gradient(135deg,#1976d2,#42a5f5)"></div>
      <div style="padding:0 16px 16px">
        <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-top:-32px;margin-bottom:10px">
          <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=${s.seed}" style="width:64px;height:64px;border-radius:50%;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.15)" loading="lazy">
          <div style="position:relative" onclick="event.stopPropagation()">
            <button onclick="toggleStaffMenu('${s.id}')" style="background:none;border:none;cursor:pointer;color:var(--gray-400);padding:4px;border-radius:4px" onmouseenter="this.style.background='rgba(0,0,0,.05)'" onmouseleave="this.style.background='none'">${IC.dots}</button>
            <div id="smenu-${s.id}" class="export-drop-menu" style="right:0;top:calc(100% + 2px);min-width:120px">
              <div class="export-drop-item" onclick="openStaffDetail('${s.id}')">${IC.eye}Xem</div>
              <div class="export-drop-item" onclick="openStaffEdit('${s.id}')">${IC.edit}Sửa</div>
              <div class="export-drop-item" style="color:var(--red)" onclick="deleteStaff('${s.id}','${s.name}')">${IC.trashSm}Xóa</div>
            </div>
          </div>
        </div>
        <div style="font-size:15px;font-weight:800;color:var(--gray-900)">${s.name}</div>
        <div style="font-size:12.5px;color:var(--gray-500);margin-bottom:8px">${s.dept}</div>
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px">
          ${roleBadge(s.role)}
          <span style="width:8px;height:8px;border-radius:50%;background:${s.status==='active'?'#22c55e':'#94a3b8'};display:inline-block"></span>
          <span style="font-size:12.5px;color:${s.status==='active'?'#16a34a':'#94a3b8'}">${s.status==='active'?'Hoạt động':'Không hoạt động'}</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;margin-bottom:12px;font-size:12.5px;color:var(--gray-500)">
          <div style="display:flex;align-items:center;gap:6px"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>${s.email}</div>
          <div style="display:flex;align-items:center;gap:6px"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 014.69 13.5a19.79 19.79 0 01-3.07-8.67A2 2 0 013.6 2.68h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>${s.phone}</div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;padding-top:10px;border-top:1px solid var(--gray-100);text-align:center">
          <div><div style="font-size:20px;font-weight:800;color:#1976d2">${s.forms}</div><div style="font-size:11px;color:var(--gray-500)">Form tạo</div></div>
          <div><div style="font-size:12px;font-weight:600;color:var(--gray-800)">${s.last}</div><div style="font-size:11px;color:var(--gray-500)">Hoạt động</div></div>
        </div>
      </div>
    </div>`).join('');
}

function filterStaff(q) { renderStaff(STAFF.filter(s=>s.name.toLowerCase().includes(q.toLowerCase()))); }
function filterByRole(r) { renderStaff(r==='all'?STAFF:STAFF.filter(s=>s.role===r)); }
function applyFilter()  { showToast('Đã áp dụng bộ lọc','success'); }
function resetFilter()  { showToast('Đã xóa bộ lọc'); }

let deleteStaffId = null;
function deleteStaff(id, name) {
  document.getElementById('smenu-'+id)?.classList.remove('open');
  deleteStaffId = id;
  const s = STAFF.find(x => x.id === id);
  if (!s) return;
  document.getElementById('sdel-avatar').textContent = s.name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
  document.getElementById('sdel-name').textContent = s.name;
  document.getElementById('sdel-dept').textContent = s.dept;
  openModal('staff-delete-modal');
}
function confirmDeleteStaff() {
  const idx = STAFF.findIndex(s => s.id === deleteStaffId);
  if (idx !== -1) {
    const name = STAFF[idx].name;
    STAFF.splice(idx, 1);
    renderStaff(STAFF);
    showToast('Đã xóa nhân viên ' + name, 'success');
  }
  closeModal('staff-delete-modal');
}
function toggleStaffMenu(id) {
  document.querySelectorAll('[id^="smenu-"].open').forEach(m => { if(m.id!=='smenu-'+id) m.classList.remove('open'); });
  document.getElementById('smenu-'+id)?.classList.toggle('open');
}
function saveAddStaff() {
  const name  = document.getElementById('as-name')?.value?.trim();
  const email = document.getElementById('as-email')?.value?.trim();
  const pw    = document.getElementById('as-pw')?.value;
  const pw2   = document.getElementById('as-pw2')?.value;
  if (!name)           { showToast('Vui lòng nhập họ và tên!','error'); return; }
  if (!email)          { showToast('Vui lòng nhập email!','error'); return; }
  if (!pw)             { showToast('Vui lòng nhập mật khẩu!','error'); return; }
  if (pw.length < 6)   { showToast('Mật khẩu phải có ít nhất 6 ký tự!','error'); return; }
  if (pw !== pw2)      { showToast('Mật khẩu nhập lại không khớp!','error'); return; }
  const seeds = ['x1','y2','z3','w4','v5'];
  STAFF.unshift({ id:'new-'+Date.now(), name, email,
    phone: document.getElementById('as-phone')?.value||'',
    role: document.getElementById('as-role')?.value||'staff',
    status: document.getElementById('as-status')?.value||'active',
    dept:'Chưa phân công', forms:0, last:'Vừa tạo',
    seed: seeds[Math.floor(Math.random()*seeds.length)], color:'#0ea5e9'
  });
  renderStaff(STAFF);
  document.getElementById('stat-total').textContent = STAFF.length;
  document.getElementById('stat-active').textContent = STAFF.filter(s=>s.status==='active').length;
  closeModal('add-staff-modal');
  showToast('Đã thêm nhân viên '+name+' thành công!','success');
}

outsideClick('staff-exp-wrap','staff-exp-menu');
document.addEventListener('click', e => {
  if (!e.target.closest('[id^="smenu-"]') && !e.target.closest('.q-dot-btn'))
    document.querySelectorAll('[id^="smenu-"].open').forEach(m=>m.classList.remove('open'));
});

renderStaff(STAFF);

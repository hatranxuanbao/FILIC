const feedbacks = [
  {id:'1',user:'Nguyễn Minh Anh',form:'Đăng ký khóa học Tiếng Anh',rating:5,msg:'Form rất dễ sử dụng và điền thông tin thuận tiện!',date:'14/03/2026',status:'new',sentiment:'positive'},
  {id:'2',user:'Trần Văn Bình',form:'Khảo sát mức độ hài lòng',rating:4,msg:'Khá tốt nhưng cần thêm một số trường thông tin.',date:'13/03/2026',status:'replied',sentiment:'positive'},
  {id:'3',user:'Lê Thị Cúc',form:'Phiếu đánh giá giảng viên',rating:2,msg:'Form bị lỗi khi submit trên điện thoại.',date:'12/03/2026',status:'new',sentiment:'negative'},
  {id:'4',user:'Phạm Quốc Dũng',form:'Đăng ký thi chứng chỉ',rating:3,msg:'Bình thường, không có gì đặc biệt.',date:'11/03/2026',status:'archived',sentiment:'neutral'},
  {id:'5',user:'Hoàng Thị Em',form:'Feedback chương trình học',rating:5,msg:'Tuyệt vời! Hệ thống hoạt động rất nhanh và ổn định.',date:'10/03/2026',status:'replied',sentiment:'positive'},
];

const sentimentIcon = s => s==='positive'?'<span style="color:#10b981;font-size:18px">😊</span>':s==='negative'?'<span style="color:#ef4444;font-size:18px">😞</span>':'<span style="color:#f59e0b;font-size:18px">😐</span>';
const fbStatusBadge = s => s==='new'?'<span class="badge badge-blue">Mới</span>':s==='replied'?'<span class="badge badge-green">Đã trả lời</span>':'<span class="badge badge-gray">Lưu trữ</span>';
const stars = n => Array.from({length:5},(_,i)=>`<svg viewBox="0 0 24 24" fill="${i<n?'#f59e0b':'#e2e8f0'}" width="14" height="14"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`).join('');

document.getElementById('page-content').innerHTML = `
  <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
    <div><h2 class="page-title">Quản lý phản hồi</h2><p class="page-sub">Xem và phản hồi ý kiến từ người dùng</p></div>
    <div style="display:flex;gap:8px;align-items:center">
      <button class="btn btn-outline" onclick="openFormFeedbackModal()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>Xem theo form
      </button>
      <button class="btn btn-outline" onclick="document.getElementById('fb-fp').style.display=document.getElementById('fb-fp').style.display==='none'?'block':'none'">${IC.filter}Lọc</button>
      ${exportDropdown('fb-exp-wrap','fb-exp-menu')}
    </div>
  </div>

  ${filterPanel('fb-fp', [
    {label:'Trạng thái', opts:['Tất cả','Mới','Đã trả lời','Lưu trữ']},
    {label:'Đánh giá', opts:['Tất cả sao','5 sao','4 sao','3 sao','Dưới 3 sao']},
    {label:'Từ ngày', type:'date'},
    {label:'Đến ngày', type:'date'},
  ])}

  <div style="display:grid;grid-template-columns:3fr 2fr;gap:20px;margin-bottom:24px">
    <div class="card card-body">
      <div style="margin-bottom:10px">
        <div style="font-size:15px;font-weight:700">Điểm hài lòng trung bình theo tháng</div>
        <div style="font-size:12.5px;color:var(--gray-500);margin-top:2px">Mức độ hài lòng học viên qua từng tháng (thang 5 sao)</div>
      </div>
      <div style="height:200px;position:relative"><canvas id="fb-line-chart" style="display:block;width:100%;height:100%"></canvas></div>
    </div>
    <div class="card card-body" style="display:flex;flex-direction:column">
      <div style="font-size:15px;font-weight:700;margin-bottom:2px">Tỷ lệ cảm xúc</div>
      <div style="font-size:12.5px;color:var(--gray-500);margin-bottom:12px">Phân loại thái độ người dùng</div>
      <div style="display:flex;flex-direction:column;align-items:center;gap:14px;flex:1">
        <div style="width:160px;height:160px;position:relative"><canvas id="fb-pie-chart" style="display:block;width:160px;height:160px"></canvas></div>
        <div id="fb-sent-legend" style="display:flex;flex-direction:column;gap:7px;font-size:12.5px;width:100%"></div>
      </div>
    </div>
  </div>

  <div class="space-y">
    ${feedbacks.map(f=>`
      <div class="card card-body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
          <div style="display:flex;align-items:center;gap:12px">
            <div class="avatar-initials" style="background:#0ea5e9;font-size:13px">${f.user.split(' ').map(w=>w[0]).join('').slice(0,2)}</div>
            <div>
              <div style="font-weight:600;font-size:14px">${f.user}</div>
              <div style="font-size:12px;color:var(--gray-500)">${f.form}</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:10px">
            ${sentimentIcon(f.sentiment)}${fbStatusBadge(f.status)}
            <span style="font-size:12px;color:var(--gray-400)">${f.date}</span>
          </div>
        </div>
        <div style="display:flex;gap:4px;margin-bottom:10px">${stars(f.rating)}</div>
        <p style="font-size:13px;color:var(--gray-700);background:var(--gray-50);padding:12px;border-radius:8px">"${f.msg}"</p>
        <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
          <button class="btn btn-sm btn-outline" onclick="openDetail('${f.id}')"
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>Chi tiết
          </button>
          <button class="btn btn-sm btn-outline" onclick="archiveFb('${f.id}')" style="color:#64748b">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/></svg>Lưu trữ
          </button>
          <button class="btn btn-sm btn-outline" onclick="openDeleteFb('${f.id}')" style="color:#ef4444;border-color:#fca5a5">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg>Xóa
          </button>
        </div>
      </div>`).join('')}
  </div>

  <!-- Reply Modal -->
  <div class="modal-overlay" id="fb-reply-modal">
    <div class="modal" style="max-width:520px" onclick="event.stopPropagation()">
      <div class="modal-header">
        <span class="modal-title">Trả lời phản hồi</span>
        <button class="icon-btn close-btn" onclick="closeModal('fb-reply-modal')">${IC.close}</button>
      </div>
      <div class="modal-body">
        <div style="background:var(--gray-50);border-radius:var(--radius);padding:14px;margin-bottom:16px">
          <div style="font-size:11px;font-weight:700;color:var(--gray-400);letter-spacing:.5px;margin-bottom:8px">HỒI DUNG GỐC</div>
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
            <div id="fb-reply-avatar" class="avatar-initials" style="background:#0ea5e9;font-size:13px;width:36px;height:36px;flex-shrink:0"></div>
            <div style="flex:1">
              <div id="fb-reply-user" style="font-weight:600;font-size:14px"></div>
              <div id="fb-reply-form" style="font-size:12px;color:var(--gray-500)"></div>
            </div>
            <div id="fb-reply-stars" style="display:flex;gap:2px"></div>
          </div>
          <p id="fb-reply-msg" style="font-size:13px;color:var(--gray-700);margin:0;line-height:1.5"></p>
        </div>
        <div class="form-group" style="margin:0">
          <label class="form-label">Nội dung trả lời</label>
          <textarea id="fb-reply-text" class="input" rows="4" style="height:auto;padding:12px" placeholder="Nhập nội dung trả lời..."></textarea>
          <div style="font-size:12px;color:var(--gray-400);margin-top:4px">Người gửi: <strong>Quản trị viên</strong></div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline" onclick="closeModal('fb-reply-modal')">Hủy</button>
        <button class="btn btn-primary" onclick="submitReply()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>Gửi trả lời
        </button>
      </div>
    </div>
  </div>

  <!-- Detail Modal -->
  <div class="modal-overlay" id="fb-detail-modal">
    <div class="modal" style="max-width:540px" onclick="event.stopPropagation()">
      <div class="modal-header">
        <span class="modal-title">Chi tiết phản hồi</span>
        <button class="icon-btn close-btn" onclick="closeModal('fb-detail-modal')">${IC.close}</button>
      </div>
      <div class="modal-body">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
          <div id="fb-det-avatar" class="avatar-initials" style="background:#0ea5e9;font-size:13px"></div>
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <span id="fb-det-user" style="font-weight:700;font-size:15px"></span>
            <span id="fb-det-status-badge"></span>
            <span id="fb-det-sent-badge"></span>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:14px;background:var(--gray-50);border-radius:var(--radius);margin-bottom:16px">
          <div><div style="font-size:11px;font-weight:700;color:var(--gray-400);letter-spacing:.5px;margin-bottom:6px">ĐÁNH GIÁ</div><div id="fb-det-stars" style="display:flex;gap:2px"></div></div>
          <div><div style="font-size:11px;font-weight:700;color:var(--gray-400);letter-spacing:.5px;margin-bottom:6px">THỜI GIAN</div><div id="fb-det-date" style="font-size:14px;font-weight:600"></div></div>
        </div>
        <div style="margin-bottom:16px">
          <div style="font-size:11px;font-weight:700;color:var(--gray-400);letter-spacing:.5px;margin-bottom:8px">NỘI DUNG PHẢN HỒI</div>
          <p id="fb-det-msg" style="font-size:14px;color:var(--gray-700);background:var(--gray-50);padding:14px;border-radius:var(--radius);line-height:1.6;margin:0"></p>
        </div>
        <div id="fb-det-reply-wrap" style="display:none">
          <div style="font-size:11px;font-weight:700;color:var(--gray-400);letter-spacing:.5px;margin-bottom:8px">TRẢ LỜI CỦA BẠN</div>
          <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:var(--radius);padding:14px">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px">
              <svg viewBox="0 0 24 24" fill="none" stroke="#0284c7" stroke-width="2" width="14" height="14"><polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 00-4-4H4"/></svg>
              <span style="font-size:12px;font-weight:600;color:#0284c7">Đã trả lời</span>
            </div>
            <p id="fb-det-reply-text" style="font-size:13px;color:var(--gray-700);margin:0;line-height:1.5"></p>
            <div id="fb-det-reply-meta" style="font-size:11px;color:var(--gray-400);margin-top:6px"></div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary" onclick="closeModal('fb-detail-modal')">Đóng</button>
      </div>
    </div>
  </div>

  <!-- Form Feedback Modal -->
  <div class="modal-overlay" id="fb-form-modal">
    <div class="modal" style="max-width:620px" onclick="event.stopPropagation()">
      <div class="modal-header">
        <span class="modal-title">Phản hồi theo form</span>
        <button class="icon-btn close-btn" onclick="closeModal('fb-form-modal')">${IC.close}</button>
      </div>
      <div class="modal-body">
        <div class="form-group" style="margin-bottom:16px">
          <label class="form-label">Chọn form</label>
          <select id="fb-form-select" class="input" onchange="renderFormFeedbacks()">
            <option value="">-- Chọn form --</option>
          </select>
        </div>
        <div id="fb-form-list" style="display:flex;flex-direction:column;gap:12px"></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary" onclick="closeModal('fb-form-modal')">Đóng</button>
      </div>
    </div>
  </div>

  <!-- Delete Confirm Modal -->
  <div class="modal-overlay" id="fb-delete-modal">
    <div class="modal" style="max-width:420px" onclick="event.stopPropagation()">
      <div class="modal-header">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:36px;height:36px;border-radius:50%;background:#fee2e2;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <svg viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2" width="18" height="18"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          </div>
          <span class="modal-title">Xác nhận xóa</span>
        </div>
        <button class="icon-btn close-btn" onclick="closeModal('fb-delete-modal')">${IC.close}</button>
      </div>
      <div class="modal-body">
        <p style="color:var(--gray-700);margin:0 0 14px">Bạn có chắc muốn xóa phản hồi này?</p>
        <div style="background:var(--gray-50);border-radius:var(--radius);padding:12px;display:flex;align-items:center;gap:10px">
          <div id="fb-del-avatar" class="avatar-initials" style="background:#0ea5e9;font-size:12px;width:36px;height:36px"></div>
          <div>
            <div id="fb-del-user" style="font-weight:600;font-size:14px"></div>
            <div id="fb-del-form" style="font-size:12px;color:var(--gray-500)"></div>
          </div>
        </div>
        <p style="font-size:12.5px;color:var(--gray-500);margin:12px 0 0">* Lưu ý: Hành động này không thể hoàn tác sau khi xác nhận.</p>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline" onclick="closeModal('fb-delete-modal')">Hủy</button>
        <button class="btn btn-primary" style="background:#dc2626;border-color:#dc2626" onclick="confirmDeleteFb()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg>Xóa
        </button>
      </div>
    </div>
  </div>
`;

// ── Feedback data store (mutable) ─────────────────────────────────
let fbList = feedbacks.map(f => ({...f, replyText:'', replyDate:''}));
let activeFbId = null;

function getFb(id) { return fbList.find(f=>f.id===id); }
function initials(name) { return name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase(); }

// ── Reply ─────────────────────────────────────────────────────────
function openReply(id) {
  const f = getFb(id); if (!f) return;
  activeFbId = id;
  document.getElementById('fb-reply-avatar').textContent = initials(f.user);
  document.getElementById('fb-reply-user').textContent = f.user;
  document.getElementById('fb-reply-form').textContent = f.form;
  document.getElementById('fb-reply-stars').innerHTML = stars(f.rating);
  document.getElementById('fb-reply-msg').textContent = f.msg;
  document.getElementById('fb-reply-text').value = f.replyText || '';
  openModal('fb-reply-modal');
}
function submitReply() {
  const text = document.getElementById('fb-reply-text').value.trim();
  if (!text) { showToast('Vui lòng nhập nội dung trả lời!','error'); return; }
  const f = getFb(activeFbId); if (!f) return;
  f.replyText = text;
  f.replyDate = new Date().toLocaleString('vi-VN');
  f.status = 'replied';
  closeModal('fb-reply-modal');
  showToast('Đã gửi trả lời thành công!','success');
}

// ── Detail ────────────────────────────────────────────────────────
function openDetail(id) {
  const f = getFb(id); if (!f) return;
  document.getElementById('fb-det-avatar').textContent = initials(f.user);
  document.getElementById('fb-det-user').textContent = f.user;
  document.getElementById('fb-det-status-badge').innerHTML = fbStatusBadge(f.status);
  document.getElementById('fb-det-sent-badge').innerHTML = sentimentIcon(f.sentiment);
  document.getElementById('fb-det-stars').innerHTML = stars(f.rating) + `<span style="font-size:13px;font-weight:700;color:#f59e0b;margin-left:4px">${f.rating}/5</span>`;
  document.getElementById('fb-det-date').textContent = f.date;
  document.getElementById('fb-det-msg').textContent = f.msg;
  const rw = document.getElementById('fb-det-reply-wrap');
  if (f.replyText) {
    rw.style.display = 'block';
    document.getElementById('fb-det-reply-text').textContent = f.replyText;
    document.getElementById('fb-det-reply-meta').textContent = 'Gửi lúc ' + f.replyDate + ' · Quản trị viên';
  } else { rw.style.display = 'none'; }
  openModal('fb-detail-modal');
}

// ── Archive ───────────────────────────────────────────────────────
function archiveFb(id) {
  const f = getFb(id); if (!f) return;
  f.status = 'archived';
  showToast('Đã lưu trữ phản hồi của ' + f.user,'success');
}

// ── Delete ────────────────────────────────────────────────────────
function openDeleteFb(id) {
  const f = getFb(id); if (!f) return;
  activeFbId = id;
  document.getElementById('fb-del-avatar').textContent = initials(f.user);
  document.getElementById('fb-del-user').textContent = f.user;
  document.getElementById('fb-del-form').textContent = f.form;
  openModal('fb-delete-modal');
}
function confirmDeleteFb() {
  const idx = fbList.findIndex(f=>f.id===activeFbId);
  if (idx !== -1) { fbList.splice(idx,1); }
  closeModal('fb-delete-modal');
  showToast('Đã xóa phản hồi','success');
  if(typeof Chart!=="undefined") buildFbCharts();
}

function applyFilter() { showToast('Đã áp dụng bộ lọc', 'success'); }
function resetFilter() { showToast('Đã xóa bộ lọc'); }
outsideClick('fb-exp-wrap', 'fb-exp-menu');

// ── View by Form ──────────────────────────────────────────────────
function openFormFeedbackModal() {
  const select = document.getElementById('fb-form-select');
  const forms = [...new Set(fbList.map(f => f.form))];
  select.innerHTML = '<option value="">-- Chọn form --</option>' +
    forms.map(f => `<option value="${f}">${f}</option>`).join('');
  document.getElementById('fb-form-list').innerHTML = '';
  openModal('fb-form-modal');
}

function renderFormFeedbacks() {
  const selected = document.getElementById('fb-form-select').value;
  const container = document.getElementById('fb-form-list');
  if (!selected) { container.innerHTML = ''; return; }
  const items = fbList.filter(f => f.form === selected);
  if (!items.length) {
    container.innerHTML = '<p style="color:var(--gray-400);text-align:center;padding:20px">Không có phản hồi nào.</p>';
    return;
  }
  container.innerHTML = items.map(f => `
    <div class="card card-body" style="padding:14px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
        <div style="display:flex;align-items:center;gap:10px">
          <div class="avatar-initials" style="background:#0ea5e9;font-size:13px;width:34px;height:34px">${initials(f.user)}</div>
          <div>
            <div style="font-weight:600;font-size:13.5px">${f.user}</div>
            <div style="font-size:12px;color:var(--gray-400)">${f.date}</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          ${sentimentIcon(f.sentiment)}${fbStatusBadge(f.status)}
        </div>
      </div>
      <div style="display:flex;gap:3px;margin-bottom:8px">${stars(f.rating)}</div>
      <p style="font-size:13px;color:var(--gray-700);background:var(--gray-50);padding:10px;border-radius:8px;margin:0">"${f.msg}"</p>
    </div>`).join('');
}

// ── Charts (data-driven from fbList) ────────────────────────────
let fbBarChart = null, fbPieChart = null;

function buildFbCharts() {
  const months = ['T10','T11','T12','T1','T2','T3','T4'];

  // ── Area line: average satisfaction score per month ──
  // Compute average rating from real data, then seed a realistic monthly trend
  const avgRating = fbList.length
    ? (fbList.reduce((s,f) => s+f.rating, 0) / fbList.length).toFixed(2)
    : 4.1;
  const baseScores = [3.8, 3.9, 4.0, 4.1, 4.2, 4.3, 4.4];
  const scale = avgRating / 4.15;
  const scores = baseScores.map(v => Math.min(5, +(v * scale).toFixed(2)));

  // Responses count per month (simulated trend)
  const respCounts = [85, 102, 130, 115, 158, 142, fbList.length > 0 ? fbList.length * 12 : 180];

  const lc = document.getElementById('fb-line-chart');
  if (lc) {
    if (fbBarChart) fbBarChart.destroy();
    fbBarChart = new Chart(lc, {
      type: 'line',
      data: {
        labels: months,
        datasets: [
          {
            label: 'Điểm hài lòng TB',
            data: scores,
            borderColor: '#f59e0b',
            backgroundColor: 'rgba(245,158,11,.12)',
            fill: true, tension: 0.45, borderWidth: 2.5,
            pointBackgroundColor: '#f59e0b', pointRadius: 5, pointHoverRadius: 7,
            yAxisID: 'y',
          },
          {
            label: 'Lượt phản hồi',
            data: respCounts,
            borderColor: '#0ea5e9',
            backgroundColor: 'rgba(14,165,233,.07)',
            fill: false, tension: 0.4, borderWidth: 2,
            pointBackgroundColor: '#0ea5e9', pointRadius: 3, pointHoverRadius: 5,
            yAxisID: 'y1',
            borderDash: [4,3],
          }
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'top', labels: { font: { size: 12 }, boxWidth: 10, padding: 10 } } },
        scales: {
          x: { grid: { color: '#f1f5f9' } },
          y: {
            type: 'linear', position: 'left',
            min: 0, max: 5,
            grid: { color: '#f1f5f9' },
            ticks: { stepSize: 1, callback: v => v+'★' },
            title: { display: true, text: 'Điểm', font: { size: 10 }, color: '#94a3b8' }
          },
          y1: {
            type: 'linear', position: 'right',
            beginAtZero: true,
            grid: { drawOnChartArea: false },
            ticks: { font: { size: 10 } },
            title: { display: true, text: 'Lượt', font: { size: 10 }, color: '#94a3b8' }
          }
        }
      }
    });
  }

  // ── Doughnut: sentiment ratio from real data ──
  const sentCounts = {
    positive: fbList.filter(f => f.sentiment === 'positive').length,
    neutral:  fbList.filter(f => f.sentiment === 'neutral').length,
    negative: fbList.filter(f => f.sentiment === 'negative').length,
  };
  const total = fbList.length || 1;
  const sentLabels = ['Tích cực','Trung lập','Tiêu cực'];
  const sentData   = [sentCounts.positive, sentCounts.neutral, sentCounts.negative];
  const sentColors = ['#10b981','#f59e0b','#ef4444'];

  const pc = document.getElementById('fb-pie-chart');
  if (pc) {
    if (fbPieChart) fbPieChart.destroy();
    fbPieChart = new Chart(pc, {
      type: 'doughnut',
      data: { labels: sentLabels, datasets: [{ data: sentData, backgroundColor: sentColors, borderWidth: 2, borderColor: '#fff', hoverOffset: 8 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: ctx => ` ${ctx.label}: ${ctx.raw} (${Math.round(ctx.raw/total*100)}%)` } }
        },
        cutout: '62%'
      }
    });
  }

  const legend = document.getElementById('fb-sent-legend');
  if (legend) {
    const emojis = ['😊','😐','😞'];
    legend.innerHTML = sentLabels.map((l,i) => {
      const pct = Math.round(sentData[i]/total*100);
      return `<div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid var(--gray-100)">
        <span style="font-size:16px">${emojis[i]}</span>
        <span style="color:var(--gray-600);flex:1;font-size:12.5px">${l}</span>
        <div style="width:50px;height:5px;background:var(--gray-100);border-radius:3px">
          <div style="height:100%;width:${pct}%;background:${sentColors[i]};border-radius:3px"></div>
        </div>
        <span style="font-weight:700;color:${sentColors[i]};font-size:12.5px;min-width:30px;text-align:right">${pct}%</span>
      </div>`;
    }).join('');
  }
}

function waitForChartAndBuildFb() {
  if (typeof Chart !== 'undefined') {
    buildFbCharts();
  } else {
    setTimeout(waitForChartAndBuildFb, 50);
  }
}
waitForChartAndBuildFb();

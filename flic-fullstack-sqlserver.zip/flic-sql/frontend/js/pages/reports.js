// Reports & Statistics Page
const MONTHLY=[
  {l:'Khóa học đang mở',v:'12',c:'+2',up:true,ico:'<path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/>',color:'#3b82f6',bg:'#eff6ff'},
  {l:'Học viên đang học',v:'340',c:'+28',up:true,ico:'<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>',color:'#10b981',bg:'#f0fdf4'},
];
const TOP_FORMS=[
  {rank:1,name:'Tiếng Anh A1 – Giao tiếp cơ bản',badge:'A1',badgeColor:'#10b981',val:'89',c:'+12',up:true,pct:98},
  {rank:2,name:'Tin học văn phòng (Word & Excel)',badge:'THVP',badgeColor:'#3b82f6',val:'76',c:'+8',up:true,pct:85},
  {rank:3,name:'Tiếng Anh B1 – Toeic 450+',badge:'B1',badgeColor:'#10b981',val:'64',c:'+5',up:true,pct:72},
  {rank:4,name:'Tin học cơ bản cho người mới',badge:'THC',badgeColor:'#6366f1',val:'58',c:'+3',up:true,pct:65},
  {rank:5,name:'Tiếng Anh B2 – Toeic 650+',badge:'B2',badgeColor:'#f59e0b',val:'53',c:'-4',up:false,pct:59},
];
const PASS_RATE=[
  {l:'Tiếng Anh A1',pass:82,fail:18,color:'#10b981'},
  {l:'Tin học VP',pass:76,fail:24,color:'#3b82f6'},
  {l:'Tiếng Anh B1',pass:68,fail:32,color:'#6366f1'},
  {l:'Tin học CB',pass:71,fail:29,color:'#8b5cf6'},
  {l:'Tiếng Anh B2',pass:55,fail:45,color:'#f59e0b'},
];
const AGE_DATA=[
  {l:'Dưới 18 tuổi',v:42,pct:12,color:'#3b82f6'},
  {l:'18 – 24 tuổi',v:118,pct:35,color:'#10b981'},
  {l:'25 – 35 tuổi',v:105,pct:31,color:'#8b5cf6'},
  {l:'36 – 45 tuổi',v:51,pct:15,color:'#f59e0b'},
  {l:'Trên 45 tuổi',v:24,pct:7,color:'#ec4899'},
];
const CHANNELS=[
  {c:'#1e40af',l:'Trực tiếp',v:'38%'},
  {c:'#93c5fd',l:'Giới thiệu',v:'36%'},
  {c:'#2563eb',l:'Mạng xã hội',v:'26%'},
];

const dot=(color,size=9)=>`<span style="width:${size}px;height:${size}px;border-radius:50%;background:${color};flex-shrink:0;display:inline-block"></span>`;
const arrow=up=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="11" height="11">${up
  ?'<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>'
  :'<polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/>'
}</svg>`;
const cardTitle=(t,s)=>`<div style="font-size:15px;font-weight:700;margin-bottom:${s?'2px':'16px'}">${t}</div>${s?`<div style="font-size:12.5px;color:var(--gray-500);margin-bottom:14px">${s}</div>`:''}`;

document.getElementById('page-content').innerHTML=`
  <div class="page-header" style="display:flex;align-items:center;justify-content:space-between">
    <div><h2 class="page-title">Báo cáo & Thống kê</h2><p class="page-sub">Phân tích chi tiết hiệu suất và xu hướng khóa học</p></div>
    <div style="display:flex;gap:8px;align-items:center">
      <div style="display:flex;background:var(--gray-100);border-radius:8px;padding:3px;gap:2px" id="period-btns">
        <button style="padding:7px 16px;border-radius:6px;font-size:13px;font-weight:700;border:none;cursor:pointer;background:#3b82f6;color:#fff" onclick="switchPeriod(this,'Tuần')">Tuần</button>
        <button style="padding:7px 16px;border-radius:6px;font-size:13px;font-weight:600;border:none;cursor:pointer;background:transparent;color:var(--gray-500)" onclick="switchPeriod(this,'Tháng')">Tháng</button>
        <button style="padding:7px 16px;border-radius:6px;font-size:13px;font-weight:600;border:none;cursor:pointer;background:transparent;color:var(--gray-500)" onclick="switchPeriod(this,'Năm')">Năm</button>
      </div>
      <button class="btn btn-outline" onclick="toggleDF()" style="display:flex;align-items:center;gap:6px"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>Tùy chỉnh</button>
      <button class="btn btn-primary" onclick="showToast('Đang chuyển sang Power BI...','success')" style="display:flex;align-items:center;gap:6px"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/><path d="M7 8h2v6H7zM11 6h2v8h-2zM15 10h2v4h-2z"/></svg>Chuyển sang Power BI</button>
    </div>
  </div>
  <div id="df-bar" style="display:none;background:var(--gray-50);border:1px solid var(--gray-200);border-radius:var(--radius);padding:12px 20px;margin-bottom:16px;align-items:center;gap:14px;flex-wrap:wrap">
    <label style="font-size:13px;font-weight:600;color:var(--gray-700)">Từ ngày:</label><input type="date" class="input" style="width:150px">
    <label style="font-size:13px;font-weight:600;color:var(--gray-700)">Đến ngày:</label><input type="date" class="input" style="width:150px">
    <button class="btn btn-primary btn-sm" onclick="showToast('Đã áp dụng','success')">Áp dụng</button>
    <button class="btn btn-outline btn-sm" onclick="document.getElementById('df-bar').style.display='none'">Hủy</button>
  </div>



  <!-- ROW 1: Chỉ tiêu & Hoàn thành + Chỉ số chất lượng -->
  <div style="display:grid;grid-template-columns:3fr 2fr;gap:20px;margin-bottom:20px">
    <div class="card card-body">
      ${cardTitle('Chỉ tiêu & Hoàn thành','Học viên mới theo tháng – 7 tháng gần nhất')}
      <div style="height:240px"><canvas id="trendChart"></canvas></div>
    </div>
    <div class="card card-body">
      ${cardTitle('Chỉ số chất lượng','Đánh giá tổng thể từ học viên')}
      <div style="height:240px"><canvas id="radarChart"></canvas></div>
    </div>
  </div>

  <!-- ROW 2: Top khóa học + Tổng quan tháng -->
  <div style="display:grid;grid-template-columns:3fr 2fr;gap:20px;margin-bottom:20px">
    <div class="card card-body">
      <div style="font-size:15px;font-weight:700;margin-bottom:16px">Top Khóa học</div>
      <div style="display:flex;flex-direction:column;gap:12px">
        ${TOP_FORMS.map(f=>`
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:22px;height:22px;border-radius:50%;background:#eff6ff;color:#3b82f6;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">${f.rank}</div>
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">
              <span style="font-size:11px;font-weight:700;color:#fff;background:${f.badgeColor};padding:1px 6px;border-radius:4px;flex-shrink:0">${f.badge}</span>
              <span style="font-size:12.5px;font-weight:500;color:var(--gray-700);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${f.name}</span>
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
              <span style="font-size:12px;font-weight:700;color:#3b82f6">${f.val} học viên</span>
              <span style="font-size:11.5px;font-weight:600;color:${f.up?'#10b981':'#ef4444'}">${f.up?'↗':'↘'} ${f.c}</span>
            </div>
            <div style="height:4px;background:var(--gray-100);border-radius:3px"><div style="height:100%;width:${f.pct}%;background:linear-gradient(90deg,#1e40af,#60a5fa);border-radius:3px"></div></div>
          </div>
        </div>`).join('')}
      </div>
    </div>
    <div class="card card-body">
      <div style="font-size:15px;font-weight:700;color:var(--gray-800);margin-bottom:18px">Tổng quan tháng này</div>
      <div style="display:flex;flex-direction:column;gap:4px">
        ${MONTHLY.map(m=>`
        <div style="padding:14px 12px;display:flex;align-items:center;gap:14px;border-bottom:1px solid var(--gray-100)">
          <div style="width:36px;height:36px;border-radius:10px;background:${m.bg};display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <svg viewBox="0 0 24 24" fill="none" stroke="${m.color}" stroke-width="2" width="18" height="18">${m.ico}</svg>
          </div>
          <div style="flex:1">
            <div style="font-size:11.5px;color:var(--gray-500);font-weight:500">${m.l}</div>
            <div style="font-size:20px;font-weight:800;color:var(--gray-900);letter-spacing:-.01em;line-height:1.2">${m.v}</div>
          </div>
          <div style="display:inline-flex;align-items:center;gap:3px;font-size:12px;font-weight:700;color:${m.up?'#10b981':'#ef4444'}">
            ${arrow(m.up)}${m.c}
          </div>
        </div>`).join('')}
      </div>
    </div>
  </div>

  <!-- ROW 3: Pie kênh + Độ tuổi -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
    <div class="card card-body" style="display:flex;flex-direction:column">
      <div style="font-size:15px;font-weight:700;margin-bottom:16px">Học viên theo kênh</div>
      <div style="flex:1;display:flex;align-items:center;justify-content:center;gap:28px">
        <div style="width:160px;height:160px;flex-shrink:0"><canvas id="rpt-customers-pie"></canvas></div>
        <div style="display:flex;flex-direction:column;gap:14px;min-width:120px">
          ${CHANNELS.map(d=>`<div style="display:flex;align-items:center;gap:9px">
            ${dot(d.c,11)}
            <div><div style="font-size:13px;color:var(--gray-700);font-weight:500">${d.l}</div><div style="font-size:12px;font-weight:700;color:var(--gray-900)">${d.v}</div></div>
          </div>`).join('')}
        </div>
      </div>
    </div>
    <div class="card card-body">
      ${cardTitle('Phân bổ học viên theo độ tuổi','Tổng 340 học viên đang học')}
      <div style="display:flex;align-items:center;justify-content:center;gap:28px">
        <div style="width:160px;height:160px;flex-shrink:0"><canvas id="ageChart"></canvas></div>
        <div style="display:flex;flex-direction:column;gap:10px;min-width:150px">
          ${AGE_DATA.map(a=>`
          <div style="display:flex;align-items:center;gap:8px">
            ${dot(a.color,10)}
            <span style="font-size:12.5px;color:var(--gray-700);flex:1">${a.l}</span>
            <span style="font-size:12.5px;font-weight:700;color:var(--gray-900)">${a.v}</span>
            <span style="font-size:11.5px;color:var(--gray-400);min-width:34px;text-align:right">${a.pct}%</span>
          </div>`).join('')}
        </div>
      </div>
    </div>
  </div>
`;

function mkChart(id,cfg){const el=document.getElementById(id);if(el)new Chart(el,cfg);}
const noLegend={legend:{display:false}};
const rAF={responsive:true,maintainAspectRatio:false};

function initCharts(){
  mkChart('rpt-customers-pie',{
    type:'pie',
    data:{labels:CHANNELS.map(d=>d.l),datasets:[{data:[38,36,26],backgroundColor:CHANNELS.map(d=>d.c),borderWidth:3,borderColor:'#fff',hoverOffset:5}]},
    options:{...rAF,plugins:{...noLegend,tooltip:{callbacks:{label:ctx=>`${ctx.label}: ${ctx.raw}%`}}}},
    plugins:[{id:'pieLbls',afterDraw(chart){
      const{ctx}=chart;
      chart.getDatasetMeta(0).data.forEach((arc,i)=>{
        const mid=arc.startAngle+(arc.endAngle-arc.startAngle)/2,r=arc.outerRadius*.62;
        ctx.save();ctx.fillStyle='#fff';ctx.font='bold 13px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
        ctx.fillText(chart.data.datasets[0].data[i]+'%',arc.x+Math.cos(mid)*r,arc.y+Math.sin(mid)*r);
        ctx.restore();
      });
    }}]
  });

  mkChart('radarChart',{
    type:'radar',
    data:{labels:['Nội dung','Giảng viên','Tương tác','Hài lòng','Hoàn thành'],datasets:[{data:[82,90,72,85,74],backgroundColor:'rgba(59,130,246,.18)',borderColor:'#3b82f6',borderWidth:2,pointBackgroundColor:'#3b82f6',pointRadius:4}]},
    options:{...rAF,plugins:noLegend,scales:{r:{min:0,max:100,ticks:{stepSize:25,font:{size:10}},grid:{color:'#e2e8f0'},angleLines:{color:'#e2e8f0'},pointLabels:{font:{size:11}}}}}
  });

  mkChart('trendChart',{
    type:'bar',
    data:{
      labels:['T9','T10','T11','T12','T1','T2','T3'],
      datasets:[
        {label:'Học viên mới',data:[92,108,125,140,158,135,168],backgroundColor:'#3b82f6',borderRadius:5},
        {label:'Chỉ tiêu',data:[100,120,130,150,160,150,180],type:'line',borderColor:'#f59e0b',backgroundColor:'transparent',borderWidth:2,borderDash:[6,4],pointRadius:4,pointBackgroundColor:'#f59e0b',tension:.3},
        {label:'Hoàn thành KH',data:[68,81,96,108,124,103,132],type:'line',borderColor:'#10b981',backgroundColor:'transparent',borderWidth:2,pointRadius:4,pointBackgroundColor:'#10b981',tension:.3},
      ]
    },
    options:{...rAF,plugins:{legend:{position:'bottom',labels:{font:{size:11},boxWidth:10,padding:12}}},scales:{x:{grid:{display:false}},y:{grid:{color:'#f8fafc'},beginAtZero:true,ticks:{stepSize:50}}}}
  });

  mkChart('ageChart',{
    type:'doughnut',
    data:{labels:AGE_DATA.map(a=>a.l),datasets:[{data:AGE_DATA.map(a=>a.v),backgroundColor:AGE_DATA.map(a=>a.color),borderWidth:2,borderColor:'#fff',hoverOffset:5}]},
    options:{...rAF,cutout:'60%',plugins:{...noLegend,tooltip:{callbacks:{label:ctx=>`${ctx.label}: ${ctx.raw} HV`}}}}
  });
}

document.readyState==='loading'?document.addEventListener('DOMContentLoaded',initCharts):setTimeout(initCharts,80);

function switchPeriod(btn,label){
  document.querySelectorAll('#period-btns button').forEach(b=>{b.style.cssText+='background:transparent;color:var(--gray-500);font-weight:600';});
  btn.style.cssText+='background:#3b82f6;color:#fff;font-weight:700';
  showToast('Xem dữ liệu theo: '+label);
}
function toggleDF(){
  const b=document.getElementById('df-bar');
  b.style.display=b.style.display==='flex'?'none':'flex';
}

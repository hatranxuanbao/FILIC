// ─── FORM MANAGEMENT - State (mirrors React source) ───

// Dữ liệu mặc định (seed)
const DEFAULT_FORMS = [
  {id:'1',name:'Đăng ký khóa học Tiếng Anh giao tiếp',cat:'Đăng ký',responses:1234,views:3456,status:'active',by:'Nguyễn Văn A',initials:'N',modified:'2 giờ trước',img:'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=400&h=200&fit=crop',color:'#0ea5e9'},
  {id:'2',name:'Khảo sát mức độ hài lòng học viên',cat:'Khảo sát',responses:987,views:2345,status:'active',by:'Trần Thị B',initials:'T',modified:'5 giờ trước',img:'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=400&h=200&fit=crop',color:'#8b5cf6'},
  {id:'3',name:'Đăng ký thi chứng chỉ Tin học',cat:'Đăng ký',responses:756,views:1890,status:'active',by:'Lê Văn C',initials:'L',modified:'1 ngày trước',img:'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=200&fit=crop',color:'#f97316'},
  {id:'4',name:'Phiếu đánh giá giảng viên',cat:'Đánh giá',responses:543,views:1234,status:'draft',by:'Phạm Thị D',initials:'P',modified:'3 ngày trước',img:'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400&h=200&fit=crop',color:'#ec4899'},
  {id:'5',name:'Đăng ký học thử miễn phí',cat:'Đăng ký',responses:1567,views:4567,status:'active',by:'Hoàng Văn E',initials:'H',modified:'4 giờ trước',img:'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400&h=200&fit=crop',color:'#10b981'},
  {id:'6',name:'Feedback chương trình học',cat:'Phản hồi',responses:432,views:890,status:'archived',by:'Vũ Thị F',initials:'V',modified:'15/12/2025',img:'https://images.unsplash.com/photo-1517842645767-c639042777db?w=400&h=200&fit=crop',color:'#64748b'},
  {id:'7',name:'Đăng ký tư vấn lộ trình học',cat:'Tư vấn',responses:678,views:1567,status:'active',by:'Đỗ Văn G',initials:'Đ',modified:'1 giờ trước',img:'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=200&fit=crop',color:'#3b82f6'},
  {id:'8',name:'Khảo sát nhu cầu mở lớp mới',cat:'Khảo sát',responses:321,views:789,status:'active',by:'Ngô Thị H',initials:'N',modified:'6 giờ trước',img:'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=400&h=200&fit=crop',color:'#f59e0b'},
];

// ── localStorage helpers ──────────────────────────────────────────
const LS_FORMS = 'flic_forms';
const LS_QUESTIONS = 'flic_library_questions';

function loadForms() {
  try {
    const raw = localStorage.getItem(LS_FORMS);
    return raw ? JSON.parse(raw) : DEFAULT_FORMS;
  } catch(e) { return DEFAULT_FORMS; }
}
function saveForms(list) {
  try { localStorage.setItem(LS_FORMS, JSON.stringify(list)); } catch(e) {}
}
function loadLibraryQuestions() {
  try {
    const raw = localStorage.getItem(LS_QUESTIONS);
    return raw ? JSON.parse(raw) : null;
  } catch(e) { return null; }
}
function saveLibraryQuestions(list) {
  try { localStorage.setItem(LS_QUESTIONS, JSON.stringify(list)); } catch(e) {}
}
// ─────────────────────────────────────────────────────────────────

let FORMS = loadForms();

// Library questions state - mirrors React initialQuestions
const DEFAULT_LIBRARY_QUESTIONS = [
  {id:'q1',text:'Bạn đã học tại FLIC được bao lâu?',type:'choice',category:'Thông tin chung',opts:['Dưới 3 tháng','3-6 tháng','6-12 tháng','Trên 1 năm']},
  {id:'q2',text:'Bạn hài lòng như thế nào về chất lượng giảng dạy tại FLIC?',type:'rating',category:'Đánh giá',opts:['1 - Rất không hài lòng','2 - Không hài lòng','3 - Bình thường','4 - Hài lòng','5 - Rất hài lòng']},
  {id:'q3',text:'Bạn đánh giá như thế nào về cơ sở vật chất của FLIC?',type:'rating',category:'Đánh giá',opts:['1 - Rất kém','2 - Kém','3 - Trung bình','4 - Tốt','5 - Rất tốt']},
  {id:'q4',text:'Bạn có giới thiệu FLIC cho bạn bè/người thân không?',type:'choice',category:'Phản hồi',opts:['Chắc chắn có','Có thể có','Chưa chắc','Không']},
  {id:'q5',text:'Khóa học nào bạn đang theo học tại FLIC?',type:'choice',category:'Thông tin chung',opts:['Tiếng Anh giao tiếp','Tiếng Anh thương mại','IELTS','TOEIC','Tin học văn phòng','Lập trình','Thiết kế đồ họa']},
  {id:'q6',text:'Giảng viên có giảng dạy nhiệt tình và dễ hiểu không?',type:'rating',category:'Đánh giá',opts:['1 - Rất không đồng ý','2 - Không đồng ý','3 - Bình thường','4 - Đồng ý','5 - Rất đồng ý']},
  {id:'q7',text:'Bạn có gặp khó khăn gì khi học tại FLIC không?',type:'text',category:'Phản hồi',opts:[]},
  {id:'q8',text:'Bạn muốn FLIC cải thiện điều gì trong thời gian tới?',type:'text',category:'Phản hồi',opts:[]},
  {id:'q9',text:'Thời gian học phù hợp với lịch làm việc của bạn chứ?',type:'choice',category:'Thông tin chung',opts:['Rất phù hợp','Phù hợp','Chấp nhận được','Không phù hợp']},
  {id:'q10',text:'Học phí của FLIC có hợp lý so với chất lượng không?',type:'rating',category:'Đánh giá',opts:['1 - Rất không hợp lý','2 - Không hợp lý','3 - Chấp nhận được','4 - Hợp lý','5 - Rất hợp lý']},
  {id:'q11',text:'Bạn biết đến FLIC qua kênh nào?',type:'choice',category:'Thông tin chung',opts:['Facebook','Google','Bạn bè giới thiệu','Website','Quảng cáo','Khác']},
  {id:'q12',text:'Nhân viên tư vấn có nhiệt tình và hỗ trợ tốt không?',type:'rating',category:'Đánh giá',opts:['1 - Rất kém','2 - Kém','3 - Trung bình','4 - Tốt','5 - Rất tốt']},
];

let libraryQuestions = loadLibraryQuestions() || DEFAULT_LIBRARY_QUESTIONS;

let selectedQuestions = new Set(); // mirrors formData.selectedQuestions
let isAddingQuestion = false;      // mirrors isAddingQuestion state
let editingQuestionId = null;      // mirrors editingQuestionId state
let newQData = {text:'', type:'choice', category:'Thông tin chung', opts:['']};
let viewMode = 'grid', filtered = [...FORMS];

const sBadge = s => s==='active'?'<span class="badge badge-green">Hoạt động</span>':s==='draft'?'<span class="badge badge-yellow">Nháp</span>':'<span class="badge badge-gray">Lưu trữ</span>';
const typeName = t => t==='choice'?'Lựa chọn':t==='rating'?'Đánh giá':'Văn bản';
const typeClass = t => t==='text'?'q-type-text':t==='rating'?'q-type-rating':'q-type-choice';
const typeIcon = t => t==='choice'?'☑':t==='rating'?'⭐':'📝';

// ─── PAGE HTML ───
document.getElementById('page-content').innerHTML = `
  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between">
    <div><h2 class="page-title">Quản lý form mẫu</h2><p class="page-sub">Tạo, chỉnh sửa và quản lý tất cả biểu mẫu của bạn</p></div>
    <div style="display:flex;gap:8px;align-items:center">
      <button class="btn btn-outline" onclick="document.getElementById('filter-panel').style.display=document.getElementById('filter-panel').style.display==='none'?'block':'none'">${IC.filter}Lọc</button>
      
      <button class="btn btn-primary" onclick="openFormModal()">${IC.plus}Tạo form mới</button>
    </div>
  </div>

  <div id="filter-panel" style="display:none;margin-bottom:16px">
    <div style="background:#fff;border:1px solid var(--gray-200);border-radius:var(--radius-lg);padding:20px;box-shadow:var(--shadow-sm)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <span style="font-size:15px;font-weight:700">Bộ lọc nâng cao</span>
        <button class="icon-btn" onclick="document.getElementById('filter-panel').style.display='none'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:14px">
        <div><label style="font-size:12.5px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:5px">Danh mục</label><select id="f-cat" class="input" style="width:100%"><option value="all">Tất cả</option><option>Đăng ký</option><option>Khảo sát</option><option>Đánh giá</option><option>Phản hồi</option></select></div>
        <div><label style="font-size:12.5px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:5px">Trạng thái</label><select id="f-status" class="input" style="width:100%"><option value="all">Tất cả</option><option value="active">Hoạt động</option><option value="draft">Nháp</option><option value="archived">Lưu trữ</option></select></div>
        <div><label style="font-size:12.5px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:5px">Từ ngày</label><input type="date" class="input" style="width:100%"></div>
        <div><label style="font-size:12.5px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:5px">Đến ngày</label><input type="date" class="input" style="width:100%"></div>
      </div>
      <div style="display:flex;gap:10px">
        <button class="btn btn-primary" onclick="applyFilter()">Áp dụng bộ lọc</button>
        <button class="btn btn-outline" onclick="resetFilter()">Xóa bộ lọc</button>
      </div>
    </div>
  </div>

  <div class="card card-body" style="margin-bottom:16px">
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <div class="input-wrap" style="flex:1;min-width:200px">
        <div class="input-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>
        <input type="text" id="search-inp" class="input" placeholder="Tìm kiếm theo tên hoặc mô tả..." oninput="filterForms()">
      </div>
      <div style="display:flex;gap:4px;background:var(--gray-100);padding:3px;border-radius:8px">
        <button id="btn-grid" class="view-btn active" onclick="setView('grid')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg></button>
        <button id="btn-list" class="view-btn" onclick="setView('list')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg></button>
      </div>
    </div>
  </div>

  <p id="forms-count" style="font-size:13px;color:var(--gray-500);margin-bottom:14px"></p>
  <div id="grid-view" class="grid-4"></div>
  <div id="list-view" class="card" style="display:none"></div>

  <div style="background:#fff;border:1px solid var(--gray-200);border-radius:var(--radius-lg);padding:12px 18px;display:flex;align-items:center;justify-content:space-between;margin-top:16px;box-shadow:var(--shadow-sm)">
    <span style="font-size:13px;color:var(--gray-500)">Trang 1 / 1</span>
    <div style="display:flex;gap:6px">
      <button class="pag-btn" disabled>Trước</button>
      <button class="pag-btn active">1</button>
      <button class="pag-btn" disabled>Sau</button>
    </div>
  </div>

  <!-- CREATE FORM MODAL -->
  <div class="modal-overlay" id="create-form-modal">
    <div class="modal" onclick="event.stopPropagation()" style="max-width:560px;border-radius:14px">
      <div class="modal-header">
        <div><div class="modal-title">Tạo form mẫu mới</div><div style="font-size:12.5px;color:var(--gray-400);margin-top:2px">Tạo biểu mẫu khảo sát với các câu hỏi từ thư viện</div></div>
        <button class="icon-btn close-btn" onclick="closeFormModal()">${IC.close}</button>
      </div>
      <div id="modal-scroll" style="padding:0 20px;max-height:72vh;overflow-y:auto">

        <!-- Thông tin cơ bản -->
        <div style="background:#fff;border:1px solid var(--gray-200);border-radius:var(--radius-lg);padding:20px;margin-bottom:14px">
          <div style="display:flex;align-items:center;gap:8px;font-size:15px;font-weight:700;color:var(--sky);margin-bottom:16px">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18" style="flex-shrink:0"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Thông tin cơ bản
          </div>
          <div class="form-group"><label class="form-label">Tên form <span style="color:var(--red)">*</span></label><input id="new-form-name" type="text" class="input" placeholder="VD: Khảo sát mức độ hài lòng học viên tháng 3/2026" style="background:#f8f9fb"></div>
          <div class="form-group"><label class="form-label">Mô tả</label><textarea class="input" style="height:72px;resize:none;padding:10px;background:#f8f9fb" placeholder="Nhập mô tả ngắn về form này..."></textarea></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div class="form-group" style="margin-bottom:0"><label class="form-label">Danh mục <span style="color:var(--red)">*</span></label><select id="new-form-cat" class="input" style="width:100%;background:#f8f9fb"><option value="">Chọn danh mục</option><option>Đăng ký</option><option>Khảo sát</option><option>Đánh giá</option><option>Phản hồi</option><option>Tư vấn</option></select></div>
            <div class="form-group" style="margin-bottom:0"><label class="form-label">Trạng thái</label><select class="input" style="width:100%;background:#f8f9fb"><option>Nháp</option><option>Hoạt động</option></select></div>
          </div>
        </div>

        <!-- Thời gian -->
        <div style="background:#fff;border:1px solid var(--gray-200);border-radius:var(--radius-lg);padding:20px;margin-bottom:14px">
          <div style="display:flex;align-items:center;gap:8px;font-size:15px;font-weight:700;color:#0284c7;margin-bottom:16px">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18" style="flex-shrink:0"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>Thời gian mở/đóng form
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div class="form-group" style="margin-bottom:0"><label class="form-label">Ngày mở form</label><input type="date" class="input" style="width:100%;background:#f8f9fb"></div>
            <div class="form-group" style="margin-bottom:0"><label class="form-label">Giờ mở form</label><input type="time" class="input" style="width:100%;background:#f8f9fb"></div>
            <div class="form-group" style="margin-bottom:0"><label class="form-label">Ngày đóng form</label><input type="date" class="input" style="width:100%;background:#f8f9fb"></div>
            <div class="form-group" style="margin-bottom:0"><label class="form-label">Giờ đóng form</label><input type="time" class="input" style="width:100%;background:#f8f9fb"></div>
          </div>
        </div>

        <!-- Info banner -->
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:var(--radius);padding:12px 14px;margin-bottom:12px;display:flex;align-items:flex-start;gap:8px;font-size:13px;color:#1e40af">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" style="flex-shrink:0;margin-top:1px"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          <span><strong>Thư viện câu hỏi</strong><br>Chọn câu hỏi từ thư viện hoặc tạo câu hỏi mới. Tất cả câu hỏi đều có thể chỉnh sửa hoặc xóa thông qua menu 3 chấm.</span>
        </div>

        <!-- Question Library -->
        <div style="border:1px solid var(--gray-200);border-radius:var(--radius-lg);overflow:hidden;margin-bottom:4px">
          <!-- Library header -->
          <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-bottom:1px solid var(--gray-200);background:#f8f9fb">
            <span style="font-size:13.5px;font-weight:700;color:var(--gray-700)">Thư viện câu hỏi (<span id="q-sel-count">0</span>/<span id="q-total-count">12</span>)</span>
            <div style="display:flex;gap:8px">
              <button class="btn btn-outline btn-sm" onclick="selectAllQ()">Chọn tất cả</button>
              <button class="btn btn-outline btn-sm" onclick="deselectAllQ()">Bỏ chọn</button>
              <button id="btn-add-q" class="btn btn-primary btn-sm" onclick="showAddQForm()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>Tạo câu hỏi mới
              </button>
            </div>
          </div>

          <!-- INLINE Add/Edit Question Form (mirrors React isAddingQuestion / editingQuestionId) -->
          <div id="inline-q-form" style="display:none;border-bottom:2px solid #0ea5e9;background:#eff6ff;padding:20px">
            <div style="display:flex;align-items:center;gap:8px;font-size:14px;font-weight:700;color:var(--gray-900);margin-bottom:16px">
              <svg viewBox="0 0 24 24" fill="none" stroke="#0ea5e9" stroke-width="2" width="18" height="18"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
              <span id="inline-q-title">Tạo câu hỏi mới</span>
            </div>

            <div class="form-group">
              <label class="form-label">Nội dung câu hỏi <span style="color:var(--red)">*</span></label>
              <textarea id="iq-text" class="input" style="height:72px;resize:none;padding:10px;background:#fff;border-radius:8px" placeholder="VD: Bạn đánh giá như thế nào về chất lượng giảng dạy?"></textarea>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
              <div>
                <label class="form-label">Loại câu hỏi <span style="color:var(--red)">*</span></label>
                <select id="iq-type" class="input" style="width:100%;background:#fff" onchange="onIQTypeChange()">
                  <option value="choice">☑ Lựa chọn</option>
                  <option value="rating">⭐ Đánh giá</option>
                  <option value="text">📝 Văn bản</option>
                </select>
              </div>
              <div>
                <label class="form-label">Danh mục</label>
                <select id="iq-cat" class="input" style="width:100%;background:#fff">
                  <option value="Thông tin chung">Thông tin chung</option>
                  <option value="Đánh giá">Đánh giá</option>
                  <option value="Phản hồi">Phản hồi</option>
                </select>
              </div>
            </div>

            <div id="iq-opts-wrap" class="form-group">
              <label class="form-label">Các lựa chọn <span style="color:var(--red)">*</span></label>
              <div id="iq-opts-list"></div>
              <button onclick="addIQOption()" style="width:100%;padding:9px;background:transparent;border:1.5px dashed #94a3b8;border-radius:8px;cursor:pointer;color:var(--gray-500);font-size:13px;font-weight:500;display:flex;align-items:center;justify-content:center;gap:6px;transition:all .15s;margin-top:4px" onmouseenter="this.style.borderColor='#0ea5e9';this.style.color='#0ea5e9'" onmouseleave="this.style.borderColor='#94a3b8';this.style.color='var(--gray-500)'">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>Thêm lựa chọn
              </button>
            </div>

            <div style="display:flex;gap:10px;margin-top:4px">
              <button class="btn btn-primary" style="flex:1;justify-content:center" onclick="saveInlineQ()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/></svg>
                <span id="iq-save-label">Lưu vào thư viện</span>
              </button>
              <button class="btn btn-outline" onclick="cancelInlineQ()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>Hủy
              </button>
            </div>
          </div>

          <!-- Questions list (rendered by JS) -->
          <div id="q-list-wrap"></div>
        </div>
      </div>

      <!-- Sticky footer -->
      <div style="position:sticky;bottom:0;background:#fff;border-top:1px solid var(--gray-200);padding:12px 20px;display:flex;align-items:center;justify-content:space-between">
        <div style="font-size:13px;color:var(--gray-500)">Đã chọn <strong id="q-bottom-count" style="color:var(--sky)">0</strong> câu hỏi</div>
        <div style="display:flex;gap:10px">
          <button class="btn btn-outline" onclick="closeFormModal()">Hủy bỏ</button>
          <button class="btn btn-primary" onclick="submitForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>Tạo form
          </button>
        </div>
      </div>
    </div>
  </div>
`;

// ─── MODAL OPEN/CLOSE ───
function openFormModal() {
  selectedQuestions = new Set();
  isAddingQuestion = false;
  editingQuestionId = null;
  document.getElementById('new-form-name').value = '';
  document.getElementById('new-form-cat').value = '';
  renderQList();
  updateQCount();
  openModal('create-form-modal');
}
function closeFormModal() {
  isAddingQuestion = false;
  editingQuestionId = null;
  closeModal('create-form-modal');
}

// ─── RENDER QUESTION LIST (grouped by category, like React groupedQuestions) ───
function renderQList() {
  const wrap = document.getElementById('q-list-wrap');
  if (!wrap) return;

  // Group by category
  const groups = {};
  libraryQuestions.forEach(q => {
    if (!groups[q.category]) groups[q.category] = [];
    groups[q.category].push(q);
  });

  let html = '';
  Object.entries(groups).forEach(([cat, questions]) => {
    // Divider
    html += `<div style="display:flex;align-items:center;gap:10px;padding:10px 16px;background:#fafbfc">
      <div style="flex:1;height:1px;background:var(--gray-200)"></div>
      <span style="font-size:10.5px;font-weight:700;color:var(--gray-400);letter-spacing:1.5px;white-space:nowrap;text-transform:uppercase">${cat}</span>
      <div style="flex:1;height:1px;background:var(--gray-200)"></div>
    </div>`;

    questions.forEach(q => {
      const checked = selectedQuestions.has(q.id);
      const isEditing = editingQuestionId === q.id;
      const tc = typeClass(q.type);
      const tn = typeName(q.type);
      const optsHtml = q.opts.length ? `<div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:5px">${q.opts.map(o=>`<span style="background:#f1f5f9;border:1px solid #e2e8f0;border-radius:4px;padding:2px 7px;font-size:11px;color:var(--gray-600)">${o}</span>`).join('')}</div>` : '';

      html += `
      <div id="qrow-${q.id}" style="display:flex;align-items:flex-start;gap:10px;padding:13px 16px;border-bottom:1px solid var(--gray-100);cursor:pointer;${checked?'background:#f0f9ff;border-left:3px solid #0ea5e9;':''};transition:background .15s" onclick="toggleQ('${q.id}')">
        <input type="checkbox" id="qcb-${q.id}" ${checked?'checked':''} onclick="event.stopPropagation();toggleQ('${q.id}')" style="width:18px;height:18px;accent-color:#7c3aed;margin-top:1px;flex-shrink:0;cursor:pointer">
        <div style="flex:1;min-width:0">
          <div style="font-size:13.5px;font-weight:600;color:var(--gray-900);margin-bottom:4px;line-height:1.4">${q.text}${q.isNew?'<span style="margin-left:6px;font-size:11px;color:#16a34a;font-weight:600">✦ Mới</span>':''}</div>
          <span class="q-type-badge ${tc}" style="display:inline-flex;align-items:center;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600">${tn}</span>
          ${optsHtml}
        </div>
        <div style="position:relative;flex-shrink:0" onclick="event.stopPropagation()">
          <button class="q-dot-btn" onclick="toggleQDotMenu('${q.id}')" style="background:none;border:none;cursor:pointer;color:var(--gray-400);padding:4px;border-radius:4px;display:flex;align-items:center" ${isAddingQuestion||editingQuestionId?'disabled':''} onmouseenter="this.style.background='var(--gray-100)'" onmouseleave="this.style.background='none'">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>
          </button>
          <div id="qdm-${q.id}" class="export-drop-menu" style="right:0;top:calc(100% + 2px);min-width:140px">
            <div class="export-drop-item" onclick="startEditQ('${q.id}')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>Sửa câu hỏi
            </div>
            <div class="export-drop-item" style="color:var(--red)" onclick="deleteQ('${q.id}')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg>Xóa câu hỏi
            </div>
          </div>
        </div>
      </div>`;
    });
  });

  wrap.innerHTML = html;
  updateQCount();
  document.getElementById('q-total-count').textContent = libraryQuestions.length;
}

// ─── TOGGLE QUESTION SELECT ───
function toggleQ(id) {
  if (selectedQuestions.has(id)) {
    selectedQuestions.delete(id);
  } else {
    selectedQuestions.add(id);
  }
  // Update row visual
  const row = document.getElementById('qrow-'+id);
  const cb = document.getElementById('qcb-'+id);
  if (row) {
    row.style.background = selectedQuestions.has(id) ? '#f0f9ff' : '';
    row.style.borderLeft = selectedQuestions.has(id) ? '3px solid #0ea5e9' : '';
  }
  if (cb) cb.checked = selectedQuestions.has(id);
  updateQCount();
}
function updateQCount() {
  const n = selectedQuestions.size;
  const el1 = document.getElementById('q-sel-count');
  const el2 = document.getElementById('q-bottom-count');
  if(el1) el1.textContent = n;
  if(el2) el2.textContent = n;
}
function selectAllQ() {
  libraryQuestions.forEach(q => selectedQuestions.add(q.id));
  renderQList();
}
function deselectAllQ() {
  selectedQuestions.clear();
  renderQList();
}

// ─── INLINE QUESTION FORM (mirrors isAddingQuestion / editingQuestionId) ───
function renderIQOptions(opts) {
  const list = document.getElementById('iq-opts-list');
  if (!list) return;
  list.innerHTML = opts.map((o, i) => `
    <div style="display:flex;gap:6px;margin-bottom:8px">
      <input type="text" class="input" value="${o}" placeholder="Lựa chọn ${i+1}" style="background:#fff;border-radius:8px;flex:1" oninput="updateIQOption(${i},this.value)">
      ${opts.length > 1 ? `<button onclick="removeIQOption(${i})" style="background:none;border:none;cursor:pointer;color:var(--gray-400);padding:4px;flex-shrink:0" onmouseenter="this.style.color='var(--red)'" onmouseleave="this.style.color='var(--gray-400)'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>` : ''}
    </div>`).join('');
}

function showAddQForm() {
  // mirrors handleAddQuestion
  isAddingQuestion = true;
  editingQuestionId = null;
  newQData = {text:'', type:'choice', category:'Thông tin chung', opts:['']};
  document.getElementById('inline-q-title').textContent = 'Tạo câu hỏi mới';
  document.getElementById('iq-save-label').textContent = 'Lưu vào thư viện';
  document.getElementById('iq-text').value = '';
  document.getElementById('iq-type').value = 'choice';
  document.getElementById('iq-cat').value = 'Thông tin chung';
  document.getElementById('iq-opts-wrap').style.display = 'block';
  renderIQOptions(['']);
  document.getElementById('inline-q-form').style.display = 'block';
  document.getElementById('btn-add-q').disabled = true;
  // Scroll into view
  setTimeout(() => document.getElementById('inline-q-form').scrollIntoView({behavior:'smooth', block:'nearest'}), 50);
}

function startEditQ(id) {
  // mirrors handleEditQuestion
  document.getElementById('qdm-'+id)?.classList.remove('open');
  const q = libraryQuestions.find(q => q.id === id);
  if (!q) return;
  editingQuestionId = id;
  isAddingQuestion = false;
  newQData = {text: q.text, type: q.type, category: q.category, opts: [...(q.opts.length ? q.opts : [''])]};
  document.getElementById('inline-q-title').textContent = 'Chỉnh sửa câu hỏi';
  document.getElementById('iq-save-label').textContent = 'Cập nhật';
  document.getElementById('iq-text').value = q.text;
  document.getElementById('iq-type').value = q.type;
  document.getElementById('iq-cat').value = q.category;
  document.getElementById('iq-opts-wrap').style.display = (q.type === 'text') ? 'none' : 'block';
  renderIQOptions(newQData.opts);
  document.getElementById('inline-q-form').style.display = 'block';
  document.getElementById('btn-add-q').disabled = true;
  setTimeout(() => document.getElementById('inline-q-form').scrollIntoView({behavior:'smooth', block:'nearest'}), 50);
}

function cancelInlineQ() {
  // mirrors handleCancelAddQuestion / handleCancelEditQuestion
  isAddingQuestion = false;
  editingQuestionId = null;
  document.getElementById('inline-q-form').style.display = 'none';
  document.getElementById('btn-add-q').disabled = false;
}

function onIQTypeChange() {
  const type = document.getElementById('iq-type').value;
  newQData.type = type;
  if (type === 'text') {
    newQData.opts = [];
    document.getElementById('iq-opts-wrap').style.display = 'none';
  } else {
    if (!newQData.opts.length) newQData.opts = [''];
    document.getElementById('iq-opts-wrap').style.display = 'block';
    renderIQOptions(newQData.opts);
  }
}

function updateIQOption(i, val) { newQData.opts[i] = val; }
function addIQOption() {
  // mirrors handleAddOption
  newQData.opts.push('');
  renderIQOptions(newQData.opts);
}
function removeIQOption(i) {
  // mirrors handleRemoveOption
  if (newQData.opts.length > 1) {
    newQData.opts.splice(i, 1);
    renderIQOptions(newQData.opts);
  }
}

function saveInlineQ() {
  const text = document.getElementById('iq-text').value.trim();
  if (!text) { showToast('Vui lòng nhập nội dung câu hỏi!', 'error'); document.getElementById('iq-text').focus(); return; }
  const type = document.getElementById('iq-type').value;
  const category = document.getElementById('iq-cat').value;
  // Read current option inputs
  const optInputs = document.querySelectorAll('#iq-opts-list input');
  const opts = type === 'text' ? [] : Array.from(optInputs).map(i => i.value.trim()).filter(Boolean);
  if (type !== 'text' && opts.length === 0) { showToast('Vui lòng thêm ít nhất một lựa chọn!', 'error'); return; }

  if (editingQuestionId) {
    // mirrors handleSaveEditQuestion
    const idx = libraryQuestions.findIndex(q => q.id === editingQuestionId);
    if (idx !== -1) libraryQuestions[idx] = {...libraryQuestions[idx], text, type, category, opts};
    saveLibraryQuestions(libraryQuestions);
    showToast('Đã cập nhật câu hỏi!', 'success');
  } else {
    // mirrors handleSaveNewQuestion - add to library AND auto-select
    const newQ = {id: 'custom-' + Date.now(), text, type, category, opts, isNew: true};
    libraryQuestions.push(newQ);
    selectedQuestions.add(newQ.id); // auto-check like React source
    saveLibraryQuestions(libraryQuestions);
    showToast('Đã thêm câu hỏi vào thư viện!', 'success');
  }

  cancelInlineQ();
  renderQList(); // re-render with updated data
}

function deleteQ(id) {
  // mirrors handleDeleteQuestion
  document.getElementById('qdm-'+id)?.classList.remove('open');
  if (!confirm('Bạn có chắc muốn xóa câu hỏi này?')) return;
  libraryQuestions = libraryQuestions.filter(q => q.id !== id);
  selectedQuestions.delete(id);
  saveLibraryQuestions(libraryQuestions);
  renderQList();
  showToast('Đã xóa câu hỏi khỏi thư viện!', 'success');
}

function toggleQDotMenu(id) {
  document.querySelectorAll('.export-drop-menu.open').forEach(m => { if(m.id !== 'qdm-'+id) m.classList.remove('open'); });
  document.getElementById('qdm-'+id)?.classList.toggle('open');
}

// ─── SUBMIT FORM ───
function submitForm() {
  const name = document.getElementById('new-form-name')?.value?.trim();
  const cat = document.getElementById('new-form-cat')?.value;
  const statusEl = document.querySelector('#create-form-modal select:last-of-type');
  const statusVal = statusEl ? (statusEl.value === 'Hoạt động' ? 'active' : 'draft') : 'draft';
  if (!name) { showToast('Vui lòng nhập tên form!', 'error'); document.getElementById('new-form-name')?.focus(); return; }
  if (!cat) { showToast('Vui lòng chọn danh mục!', 'error'); return; }
  if (selectedQuestions.size === 0) { showToast('Vui lòng chọn ít nhất 1 câu hỏi!', 'error'); return; }

  // Tạo form mới và lưu vào FORMS + localStorage
  const colors = ['#0ea5e9','#8b5cf6','#f97316','#ec4899','#10b981','#3b82f6','#f59e0b','#64748b'];
  const imgs = [
    'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=400&h=200&fit=crop',
    'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=400&h=200&fit=crop',
    'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=200&fit=crop',
    'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=200&fit=crop',
  ];
  const formId = 'f-' + Date.now();
  // Lấy danh sách câu hỏi đã chọn
  const chosenQuestions = libraryQuestions.filter(q => selectedQuestions.has(q.id));

  const newForm = {
    id: formId, name, cat,
    responses: 0, views: 0, status: statusVal,
    by: 'admin', initials: 'A', modified: 'Vừa tạo',
    img: imgs[Math.floor(Math.random() * imgs.length)],
    color: colors[Math.floor(Math.random() * colors.length)],
    questions: chosenQuestions,
  };
  FORMS.unshift(newForm);
  saveForms(FORMS);
  filtered = [...FORMS];
  if(typeof Chart!=="undefined") {}

  // Thêm vào hàng chờ phê duyệt
  const priorityOpts = ['high','medium','low'];
  const newApproval = {
    id: formId, form: name, by: 'admin',
    date: new Date().toLocaleDateString('vi-VN', {day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'}).replace(',',''),
    status: 'pending', cat,
    priority: priorityOpts[Math.floor(Math.random() * priorityOpts.length)],
    questions: chosenQuestions,
  };
  try {
    const existing = JSON.parse(localStorage.getItem('flic_approvals') || '[]');
    existing.unshift(newApproval);
    localStorage.setItem('flic_approvals', JSON.stringify(existing));
  } catch(e) {}

  closeFormModal();
  showToast(`Đã tạo form "${name}" thành công!`, 'success');
  setTimeout(() => { window.location.href = 'approval.html'; }, 900);
}

// ─── FORM CARDS GRID / LIST ───
function renderGrid(list) {
  document.getElementById('forms-count').innerHTML = `Hiển thị <strong style="color:var(--gray-800)">${list.length}</strong> trong tổng số <strong style="color:var(--gray-800)">${FORMS.length}</strong> form`;
  if (viewMode === 'grid') {
    document.getElementById('grid-view').innerHTML = list.map(f=>`
      <div class="form-card">
        <div class="form-card-thumb">
          <img src="${f.img}" alt="${f.name}" loading="lazy">
          <div style="position:absolute;top:10px;left:10px">${sBadge(f.status)}</div>
          <div style="position:absolute;bottom:0;left:0;right:0;height:3px;background:${f.color}"></div>
          <div class="form-card-overlay">
            <button class="btn btn-outline btn-sm" style="background:rgba(255,255,255,.9)" onclick="showToast('Xem form')">${IC.eye}</button>
            <button class="btn btn-outline btn-sm" style="background:rgba(255,255,255,.9)" onclick="openEditModal('${f.id}')">${IC.edit}Sửa</button>
          </div>
        </div>
        <div class="form-card-body">
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
            <span style="width:8px;height:8px;border-radius:50%;background:${f.color};flex-shrink:0;display:inline-block"></span>
            <span class="badge" style="font-size:11px;padding:2px 7px;background:var(--gray-100);color:var(--gray-600)">${f.cat}</span>
          </div>
          <div class="form-card-name">${f.name}</div>
          <div class="form-card-meta" style="margin-top:8px">
            <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>${f.responses.toLocaleString()}</span>
            <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>${f.views.toLocaleString()}</span>
            <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>${f.modified}</span>
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;padding-top:10px;border-top:1px solid var(--gray-100);margin-top:10px">
            <div style="display:flex;align-items:center;gap:6px">
              <div style="width:24px;height:24px;border-radius:50%;background:${f.color};display:flex;align-items:center;justify-content:center;color:#fff;font-size:11px;font-weight:700">${f.initials}</div>
              <span style="font-size:12px;color:var(--gray-600)">${f.by}</span>
            </div>
            <div style="position:relative" onclick="event.stopPropagation()">
              <button class="icon-btn" onclick="toggleFormMenu('${f.id}')">${IC.dots}</button>
              <div id="fmenu-${f.id}" class="export-drop-menu" style="right:0;top:calc(100% + 2px);min-width:130px">
                <div class="export-drop-item" onclick="openEditModal('${f.id}');document.getElementById('fmenu-${f.id}').classList.remove('open')">${IC.edit}Chỉnh sửa</div>
                <div class="export-drop-item" style="color:var(--red)" onclick="deleteForm('${f.id}');document.getElementById('fmenu-${f.id}').classList.remove('open')">${IC.trashSm}Xóa form</div>
              </div>
            </div>
          </div>
        </div>
      </div>`).join('');
    document.getElementById('list-view').style.display = 'none';
    document.getElementById('grid-view').style.display = '';
  } else {
    document.getElementById('list-view').innerHTML = list.map(f=>`
      <div style="display:flex;align-items:center;gap:12px;padding:14px 16px;border-bottom:1px solid var(--gray-100)">
        <div style="width:4px;height:36px;border-radius:2px;background:${f.color};flex-shrink:0"></div>
        <img src="${f.img}" style="width:48px;height:36px;border-radius:6px;object-fit:cover;flex-shrink:0">
        <div style="flex:1;min-width:0"><div style="font-weight:500;font-size:13px;color:var(--gray-900);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${f.name}</div><div style="font-size:12px;color:var(--gray-500)">${f.cat}</div></div>
        ${sBadge(f.status)}
        <div style="display:flex;gap:16px;font-size:12px;color:var(--gray-500)"><span>${f.responses.toLocaleString()}</span><span>${f.views.toLocaleString()}</span><span>${f.modified}</span></div>
        <div style="position:relative" onclick="event.stopPropagation()">
          <button class="icon-btn" onclick="toggleFormMenu('list-${f.id}')">${IC.dots}</button>
          <div id="fmenu-list-${f.id}" class="export-drop-menu" style="right:0;top:calc(100% + 2px);min-width:130px">
            <div class="export-drop-item" onclick="openEditModal('${f.id}');document.getElementById('fmenu-list-${f.id}').classList.remove('open')">${IC.edit}Chỉnh sửa</div>
            <div class="export-drop-item" style="color:var(--red)" onclick="deleteForm('${f.id}');document.getElementById('fmenu-list-${f.id}').classList.remove('open')">${IC.trashSm}Xóa form</div>
          </div>
        </div>
      </div>`).join('');
    document.getElementById('grid-view').style.display = 'none';
    document.getElementById('list-view').style.display = 'block';
  }
}

function setView(v) {
  viewMode = v;
  document.getElementById('btn-grid').classList.toggle('active', v==='grid');
  document.getElementById('btn-list').classList.toggle('active', v==='list');
  renderGrid(filtered);
}
function filterForms() {
  const q = document.getElementById('search-inp').value.toLowerCase();
  filtered = FORMS.filter(f => f.name.toLowerCase().includes(q));
  renderGrid(filtered);
}
function applyFilter() {
  const cat = document.getElementById('f-cat').value;
  const status = document.getElementById('f-status').value;
  filtered = FORMS.filter(f => (cat==='all'||f.cat===cat) && (status==='all'||f.status===status));
  renderGrid(filtered);
  showToast(`Đã lọc: ${filtered.length} kết quả`, 'success');
}
function resetFilter() { filtered = [...FORMS]; renderGrid(filtered); showToast('Đã xóa bộ lọc'); }

// Close dropdowns on outside click

document.addEventListener('click', e => {
  if (!e.target.closest('.q-dot-btn') && !e.target.closest('.export-drop-menu[id^="qdm-"]')) {
    document.querySelectorAll('[id^="qdm-"].open').forEach(m => m.classList.remove('open'));
  }
  if (!e.target.closest('[id^="fmenu-"]') && !e.target.closest('.icon-btn')) {
    document.querySelectorAll('[id^="fmenu-"].open').forEach(m => m.classList.remove('open'));
  }
});

function toggleFormMenu(id) {
  document.querySelectorAll('[id^="fmenu-"].open').forEach(m => { if (m.id !== 'fmenu-'+id) m.classList.remove('open'); });
  document.getElementById('fmenu-'+id)?.classList.toggle('open');
}

function deleteForm(id) {
  const f = FORMS.find(f => f.id === id);
  if (!f) return;
  if (!confirm(`Bạn có chắc muốn xóa form "${f.name}"?`)) return;
  FORMS.splice(FORMS.findIndex(f => f.id === id), 1);
  saveForms(FORMS);
  filtered = filtered.filter(f => f.id !== id);
  renderGrid(filtered);

  showToast(`Đã xóa form "${f.name}"`, 'error');
}

function openEditModal(id) {
  const f = FORMS.find(f => f.id === id);
  if (!f) return;
  document.getElementById('edit-form-id').value = f.id;
  document.getElementById('edit-form-name').value = f.name;
  document.getElementById('edit-form-cat').value = f.cat;
  document.getElementById('edit-form-status').value =
    f.status === 'active' ? 'Hoạt động' : f.status === 'draft' ? 'Nháp' : 'Lưu trữ';
  openModal('edit-form-modal');
}

function saveEditForm() {
  const id   = document.getElementById('edit-form-id').value;
  const name = document.getElementById('edit-form-name').value.trim();
  const cat  = document.getElementById('edit-form-cat').value;
  const sv   = document.getElementById('edit-form-status').value;
  if (!name) { showToast('Vui lòng nhập tên form!', 'error'); document.getElementById('edit-form-name').focus(); return; }
  if (!cat)  { showToast('Vui lòng chọn danh mục!', 'error'); return; }
  const status = sv === 'Hoạt động' ? 'active' : sv === 'Nháp' ? 'draft' : 'archived';
  const idx = FORMS.findIndex(f => f.id === id);
  if (idx !== -1) {
    FORMS[idx] = { ...FORMS[idx], name, cat, status, modified: 'Vừa cập nhật' };
    saveForms(FORMS);
    filtered = filtered.map(f => f.id === id ? FORMS[idx] : f);
    renderGrid(filtered);
  }
  closeModal('edit-form-modal');
  showToast(`Đã cập nhật form "${name}"`, 'success');
}

// Inject edit modal
document.getElementById('page-content').insertAdjacentHTML('beforeend', `
  <div class="modal-overlay" id="edit-form-modal">
    <div class="modal" onclick="event.stopPropagation()" style="max-width:480px;border-radius:14px">
      <div class="modal-header">
        <div><div class="modal-title">Chỉnh sửa form</div><div style="font-size:12.5px;color:var(--gray-400);margin-top:2px">Cập nhật thông tin biểu mẫu</div></div>
        <button class="icon-btn close-btn" onclick="closeModal('edit-form-modal')">${IC.close}</button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="edit-form-id">
        <div class="form-group">
          <label class="form-label">Tên form <span style="color:var(--red)">*</span></label>
          <input id="edit-form-name" type="text" class="input" placeholder="Tên biểu mẫu">
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label">Danh mục <span style="color:var(--red)">*</span></label>
            <select id="edit-form-cat" class="input" style="width:100%">
              <option value="">Chọn danh mục</option>
              <option>Đăng ký</option><option>Khảo sát</option><option>Đánh giá</option><option>Phản hồi</option><option>Tư vấn</option>
            </select>
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label">Trạng thái</label>
            <select id="edit-form-status" class="input" style="width:100%">
              <option>Hoạt động</option><option>Nháp</option><option>Lưu trữ</option>
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline" onclick="closeModal('edit-form-modal')">Hủy</button>
        <button class="btn btn-primary" onclick="saveEditForm()">${IC.save}Lưu thay đổi</button>
      </div>
    </div>
  </div>
`);

// Init
renderGrid(filtered);

// ── Charts (data-driven from FORMS list) ────────────────────────
let fmLineChart = null;
let fmDoughnutChart = null;
const CAT_COLORS = {'Đăng ký':'#0ea5e9','Khảo sát':'#8b5cf6','Đánh giá':'#f97316','Phản hồi':'#10b981','Khác':'#64748b'};



// ── Load form từ API thật ────────────────────────────────────────────
async function loadFormsFromAPI() {
  try {
    if (typeof api === 'undefined') return;
    const res = await api.getForms();
    if (!res || !res.forms || !res.forms.length) return;

    // Map MongoDB fields → UI fields
    const mapped = res.forms.map(f => ({
      id:        f._id,
      name:      f.tenFormMau,
      cat:       f.danhMuc     || 'Đăng ký',
      status:    f.trangThai   || 'draft',
      responses: f.soLuotPhanHoi || 0,
      views:     f.soLuotXem  || 0,
      by:        f.nguoiTao?.hoTen || 'Admin',
      initials:  (f.nguoiTao?.hoTen || 'A').split(' ').map(w=>w[0]).join('').slice(0,2),
      modified:  new Date(f.updatedAt).toLocaleDateString('vi-VN'),
      img:       f.thumbnailUrl || 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=400&h=200&fit=crop',
      color:     f.mauSac || '#0ea5e9',
      questions: (f.cauHoi || []).map(q => ({
        id:   q._id,
        text: q.noiDung,
        type: q.loaiCauHoi === 'dropdown' || q.loaiCauHoi === 'radio' || q.loaiCauHoi === 'checkbox' ? 'choice' : q.loaiCauHoi === 'rating' ? 'rating' : 'text',
        opts: q.tuyChon || [],
      })),
    }));

    // Merge với FORMS (ưu tiên API data)
    FORMS.length = 0;
    mapped.forEach(f => FORMS.push(f));
    filtered = [...FORMS];
    renderGrid(filtered);
    if (typeof buildFmCharts === 'function') setTimeout(buildFmCharts, 100);
  } catch(e) { console.log('Form API error:', e.message); }
}

// Override submitForm để lưu vào MongoDB
async function submitFormToAPI(name, cat, statusVal, chosenQuestions) {
  try {
    const user = JSON.parse(localStorage.getItem('flic_user') || '{}');
    const cauHoi = chosenQuestions.map((q, i) => ({
      noiDung:    q.text,
      loaiCauHoi: q.type === 'choice' ? 'radio' : q.type === 'rating' ? 'rating' : 'text',
      batBuoc:    true,
      thuTu:      i + 1,
      tuyChon:    q.opts || [],
    }));

    const res = await api.createForm({
      tenFormMau: name,
      danhMuc:    cat,
      trangThai:  statusVal,
      cauHoi,
    });

    if (res.success) {
      showToast(`Đã tạo form "${name}" và lưu vào database!`, 'success');
      await loadFormsFromAPI();
    }
    return res;
  } catch(e) {
    showToast('Lỗi lưu form: ' + e.message, 'error');
    throw e;
  }
}

document.addEventListener('DOMContentLoaded', loadFormsFromAPI);

// ── localStorage helpers ──────────────────────────────────────────
const LS_NOTIFS = 'flic_notifications';
const DEFAULT_NOTIFICATIONS = [
  {id:'1',title:'Cập nhật hệ thống v2.0.1',msg:'Hệ thống đã được cập nhật với nhiều tính năng mới.',type:'info',recipients:'Tất cả nhân viên',status:'sent',date:'5 phút trước',read:45,total:120},
  {id:'2',title:'Nhắc nhở: Deadline báo cáo tháng 3',msg:'Vui lòng hoàn thành báo cáo trước ngày 10/03/2026.',type:'warning',recipients:'Phòng Ngoại ngữ',status:'sent',date:'2 giờ trước',read:67,total:80},
  {id:'3',title:'Form mới cần phê duyệt',msg:'Có 3 form đang chờ phê duyệt của bạn.',type:'success',recipients:'Quản lý',status:'sent',date:'5 giờ trước',read:12,total:12},
  {id:'4',title:'Bảo trì hệ thống đêm nay',msg:'Hệ thống sẽ bảo trì từ 22:00 - 24:00.',type:'error',recipients:'Tất cả nhân viên',status:'scheduled',date:'20/03/2026 22:00',read:0,total:120},
  {id:'5',title:'Chào mừng nhân viên mới',msg:'Vũ Thị F đã gia nhập Phòng Tin học.',type:'info',recipients:'Phòng Tin học',status:'draft',date:'Chưa gửi',read:0,total:35},
];
function loadNotifs() {
  try { const r = localStorage.getItem(LS_NOTIFS); return r ? JSON.parse(r) : DEFAULT_NOTIFICATIONS; } catch(e) { return DEFAULT_NOTIFICATIONS; }
}
function saveNotifs(list) {
  try { localStorage.setItem(LS_NOTIFS, JSON.stringify(list)); } catch(e) {}
}
// ─────────────────────────────────────────────────────────────────

let notifications = loadNotifs();

const typeStyle = {
  info:{bg:'#dbeafe',color:'#2563eb'},
  success:{bg:'#dcfce7',color:'#16a34a'},
  warning:{bg:'#fef9c3',color:'#ca8a04'},
  error:{bg:'#fee2e2',color:'#dc2626'},
};
const typeMap = {'Thông tin':'info','Thành công':'success','Cảnh báo':'warning','Lỗi':'error'};
const statusBadge = s => s==='sent'?'<span class="badge badge-green">Đã gửi</span>':s==='scheduled'?'<span class="badge badge-blue">Đã lên lịch</span>':'<span class="badge badge-gray">Nháp</span>';

document.getElementById('page-content').innerHTML = `
  <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
    <div><h2 class="page-title">Quản lý thông báo</h2><p class="page-sub">Tạo và quản lý thông báo đến nhân viên</p></div>
    <button class="btn btn-primary" onclick="openModal('create-notif-modal')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      Tạo thông báo
    </button>
  </div>

  <!-- Stats -->
  <div class="grid-4" style="margin-bottom:24px" id="notif-stats"></div>

  <!-- Search -->
  <div class="card card-body" style="margin-bottom:20px">
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <div class="input-wrap" style="flex:1;min-width:200px">
        <div class="input-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>
        <input type="text" id="notif-search" class="input" placeholder="Tìm kiếm thông báo..." oninput="renderNotifList()">
      </div>
      <select id="notif-filter-type" class="input" style="width:auto" onchange="renderNotifList()"><option value="">Tất cả loại</option><option>Thông tin</option><option>Thành công</option><option>Cảnh báo</option><option>Lỗi</option></select>
      <select id="notif-filter-status" class="input" style="width:auto" onchange="renderNotifList()"><option value="">Tất cả trạng thái</option><option value="sent">Đã gửi</option><option value="scheduled">Lên lịch</option><option value="draft">Nháp</option></select>
    </div>
  </div>

  <!-- Notification list -->
  <div class="space-y" id="notif-list"></div>

  <!-- Create Modal -->
  <div class="modal-overlay" id="create-notif-modal">
    <div class="modal" style="max-width:560px;width:100%" onclick="event.stopPropagation()">
      <div class="modal-header">
        <span class="modal-title">Tạo thông báo mới</span>
        <button class="icon-btn close-btn" onclick="closeModal('create-notif-modal')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
      <div class="modal-body" style="padding:24px;display:flex;flex-direction:column;gap:20px">

        <!-- Tiêu đề -->
        <div class="form-group" style="margin:0">
          <label class="form-label">Tiêu đề thông báo <span style="color:var(--red)">*</span></label>
          <input id="notif-title" type="text" class="input" placeholder="Nhập tiêu đề thông báo...">
        </div>

        <!-- Nội dung -->
        <div class="form-group" style="margin:0">
          <label class="form-label">Nội dung thông báo <span style="color:var(--red)">*</span></label>
          <textarea id="notif-msg" class="input" rows="2" maxlength="200" style="height:auto;padding:12px;resize:none" placeholder="Nhập nội dung thông báo..." oninput="const c=this.value.length;document.getElementById('notif-char-count').textContent=c;document.getElementById('notif-char-count').style.color=c>180?'#ef4444':'var(--gray-400)'"></textarea>
          <div style="font-size:12px;color:var(--gray-400);margin-top:4px;display:flex;justify-content:space-between"><span>Tối đa 200 ký tự</span><span><span id="notif-char-count">0</span>/200</span></div>
        </div>

        <!-- Người nhận -->
        <div class="form-group" style="margin:0">
          <label class="form-label">Người nhận <span style="color:var(--red)">*</span></label>
          <div style="margin-top:6px;display:flex;flex-direction:column;gap:8px">
            <input id="notif-email-input" type="text" class="input" placeholder="Nhập tên, ID hoặc email người nhận..." onkeydown="handleEmailKey(event)">
            <div id="notif-email-tags" style="display:flex;flex-wrap:wrap;gap:6px;min-height:0"></div>
            <div style="font-size:12px;color:var(--gray-400)">Nhấn <kbd style="background:var(--gray-100);border:1px solid var(--gray-200);border-radius:4px;padding:1px 6px;font-size:11px">Enter</kbd> hoặc dấu phẩy để thêm nhiều người nhận</div>
          </div>
          <input type="hidden" id="notif-recip" value="">
        </div>

        <!-- Thời gian gửi -->
        <div class="form-group" style="margin:0">
          <label class="form-label">Thời gian gửi <span style="color:var(--red)">*</span></label>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:6px">
            <div>
              <div style="font-size:12px;color:var(--gray-500);margin-bottom:4px">Ngày gửi</div>
              <input type="date" id="notif-send-date" class="input">
            </div>
            <div>
              <div style="font-size:12px;color:var(--gray-500);margin-bottom:4px">Giờ gửi</div>
              <input type="time" id="notif-send-time-val" class="input">
            </div>
          </div>
        </div>

      </div>
      <div class="modal-footer" style="display:flex;gap:12px">
        <button class="btn btn-outline" style="flex:1;justify-content:center" onclick="closeModal('create-notif-modal')">Hủy</button>
        <button class="btn btn-primary" style="flex:1;justify-content:center;gap:8px" onclick="saveNotifAction('sent')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          Gửi ngay
        </button>
      </div>
    </div>
  </div>
`;

// ── Render helpers ────────────────────────────────────────────────
function renderNotifStats() {
  const total = notifications.length;
  const sent = notifications.filter(n=>n.status==='sent').length;
  const scheduled = notifications.filter(n=>n.status==='scheduled').length;
  const draft = notifications.filter(n=>n.status==='draft').length;
  document.getElementById('notif-stats').innerHTML = [
    {label:'Tổng thông báo',value:total,color:'#0ea5e9',bg:'#e0f2fe'},
    {label:'Đã gửi',value:sent,color:'#10b981',bg:'#dcfce7'},
    {label:'Lên lịch',value:scheduled,color:'#8b5cf6',bg:'#f3e8ff'},
    {label:'Nháp',value:draft,color:'#f59e0b',bg:'#fef9c3'},
  ].map(s=>`<div class="card stat-card" style="padding:20px"><div class="stat-label">${s.label}</div><div class="stat-value" style="color:${s.color}">${s.value}</div></div>`).join('');
}

function renderNotifList() {
  const q = (document.getElementById('notif-search')?.value||'').toLowerCase();
  const ft = document.getElementById('notif-filter-type')?.value||'';
  const fs = document.getElementById('notif-filter-status')?.value||'';
  const list = notifications.filter(n => {
    const matchQ = !q || n.title.toLowerCase().includes(q) || n.msg.toLowerCase().includes(q);
    const matchT = !ft || (typeMap[ft]||ft) === n.type;
    const matchS = !fs || n.status === fs;
    return matchQ && matchT && matchS;
  });
  document.getElementById('notif-list').innerHTML = list.map(n => {
    const ts = typeStyle[n.type];
    const pct = n.total > 0 ? Math.round(n.read/n.total*100) : 0;
    return `
    <div class="card card-body">
      <div style="display:flex;align-items:flex-start;gap:14px">
        <div style="width:40px;height:40px;border-radius:50%;background:${ts.bg};display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <svg viewBox="0 0 24 24" fill="none" stroke="${ts.color}" stroke-width="2" width="18" height="18"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        </div>
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
            <div style="font-weight:600;font-size:14px">${n.title}</div>
            <div style="display:flex;align-items:center;gap:8px">
              ${statusBadge(n.status)}
              <span style="font-size:12px;color:var(--gray-400)">${n.date}</span>
            </div>
          </div>
          <div style="font-size:13px;color:var(--gray-600);margin-bottom:8px">${n.msg}</div>
          <div style="display:flex;align-items:center;gap:16px">
            <span style="font-size:12px;color:var(--gray-500)">📧 ${n.recipients}</span>
            ${n.status==='sent'?`
              <div style="display:flex;align-items:center;gap:8px">
                <div class="progress" style="width:80px"><div class="progress-bar" style="width:${pct}%;background:#0ea5e9"></div></div>
                <span style="font-size:12px;color:var(--gray-500)">${n.read}/${n.total} đã đọc (${pct}%)</span>
              </div>
            `:''}
          </div>
        </div>
        <div style="display:flex;gap:4px;flex-shrink:0">
          <button class="icon-btn" onclick="showToast('Xem chi tiết thông báo')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></button>
          <button class="icon-btn" style="color:var(--red)" onclick="deleteNotif('${n.id}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg></button>
        </div>
      </div>
    </div>`;
  }).join('');
}


// ── Email tag input ────────────────────────────────────────────────
let emailTags = [];
function handleEmailKey(e) {
  if (e.key === 'Enter' || e.key === ',') {
    e.preventDefault();
    const val = e.target.value.replace(/,/g,'').trim();
    if (val && !emailTags.includes(val)) {
      emailTags.push(val);
      renderEmailTags();
      document.getElementById('notif-recip').value = emailTags.join(',');
    }
    e.target.value = '';
  }
}
function removeEmailTag(email) {
  emailTags = emailTags.filter(e => e !== email);
  renderEmailTags();
  document.getElementById('notif-recip').value = emailTags.join(',');
}
function renderEmailTags() {
  const wrap = document.getElementById('notif-email-tags');
  if (!wrap) return;
  wrap.innerHTML = emailTags.map(e => `
    <span style="display:inline-flex;align-items:center;gap:5px;background:#e0f2fe;color:#0284c7;border-radius:999px;padding:3px 10px 3px 12px;font-size:12px;font-weight:500">
      ${e}
      <button onclick="removeEmailTag('${e}')" style="background:none;border:none;cursor:pointer;color:#0284c7;padding:0;display:flex;line-height:1" title="Xóa">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="12" height="12"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </span>`).join('');
}

function saveNotifAction(status) {
  const title = document.getElementById('notif-title').value.trim();
  const msg = document.getElementById('notif-msg').value.trim();
  if (!title) { showToast('Vui lòng nhập tiêu đề!', 'error'); document.getElementById('notif-title').focus(); return; }
  if (!msg) { showToast('Vui lòng nhập nội dung!', 'error'); document.getElementById('notif-msg').focus(); return; }
  const recipients = document.getElementById('notif-recip').value.trim();
  if (!recipients) { showToast('Vui lòng thêm ít nhất một người nhận!', 'error'); document.getElementById('notif-email-input').focus(); return; }
  const sendDate = document.getElementById('notif-send-date').value;
  const sendTime = document.getElementById('notif-send-time-val').value;
  if (!sendDate || !sendTime) { showToast('Vui lòng chọn ngày và giờ gửi!', 'error'); return; }
  const d = new Date(`${sendDate}T${sendTime}`);
  const dateStr = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
  const newNotif = {
    id: 'n-' + Date.now(),
    title, msg, type: 'info', recipients,
    status: 'scheduled',
    date: dateStr,
    read: 0,
    total: emailTags.length,
  };
  notifications.unshift(newNotif);
  saveNotifs(notifications);
  closeModal('create-notif-modal');
  document.getElementById('notif-title').value = '';
  document.getElementById('notif-msg').value = '';
  document.getElementById('notif-char-count').textContent = '0';
  document.getElementById('notif-send-date').value = '';
  document.getElementById('notif-send-time-val').value = '';
  emailTags = [];
  renderEmailTags();
  document.getElementById('notif-recip').value = '';
  renderNotifStats();
  renderNotifList();
  showToast('Đã lên lịch gửi thông báo!', 'success');
}

function deleteNotif(id) {
  if (!confirm('Bạn có chắc muốn xóa thông báo này?')) return;
  notifications = notifications.filter(n => n.id !== id);
  saveNotifs(notifications);
  renderNotifStats();
  renderNotifList();
  showToast('Đã xóa thông báo', 'error');
}

// Init
renderNotifStats();
renderNotifList();

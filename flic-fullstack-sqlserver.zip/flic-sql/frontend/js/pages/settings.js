document.getElementById('page-content').innerHTML = `
  <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
    <div><h2 class="page-title">Cài đặt</h2><p class="page-sub">Quản lý cài đặt tài khoản và hệ thống</p></div>
    <button class="btn btn-primary" onclick="saveSettings()">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
      Lưu thay đổi
    </button>
  </div>

  <div data-tabs>
    <div class="tabs">
      <button class="tab-btn active" data-tab="account">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14" style="margin-right:4px"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Tài khoản
      </button>
      <button class="tab-btn" data-tab="notifications">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14" style="margin-right:4px"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>Thông báo
      </button>
      <button class="tab-btn" data-tab="security">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14" style="margin-right:4px"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>Bảo mật
      </button>
      <button class="tab-btn" data-tab="appearance">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14" style="margin-right:4px"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>Giao diện
      </button>
    </div>

    <!-- Account Tab -->
    <div class="tab-content active" data-tab-content="account">
      <div class="card card-body">
        <div style="display:flex;align-items:center;gap:20px;margin-bottom:28px;padding-bottom:24px;border-bottom:1px solid var(--gray-200)">
          <div class="avatar-initials" style="background:#0ea5e9;width:72px;height:72px;font-size:24px">NA</div>
          <div>
            <div style="font-size:18px;font-weight:600">Nguyễn Văn A</div>
            <div style="font-size:13px;color:var(--gray-500)">Admin • Quản lý hệ thống</div>
            <button class="btn btn-outline btn-sm" style="margin-top:8px" onclick="showToast('Đang mở chọn ảnh...')">Đổi ảnh đại diện</button>
          </div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label class="form-label">Họ và tên</label><input type="text" class="input" value="Nguyễn Văn A"></div>
          <div class="form-group"><label class="form-label">Email</label><input type="email" class="input" value="nguyenvana@flic.edu.vn"></div>
          <div class="form-group"><label class="form-label">Số điện thoại</label><input type="tel" class="input" value="0912345678"></div>
          <div class="form-group"><label class="form-label">Phòng ban</label><input type="text" class="input" value="Quản lý hệ thống" readonly style="background:var(--gray-50)"></div>
        </div>
      </div>
    </div>

    <!-- Notifications Tab -->
    <div class="tab-content" data-tab-content="notifications">
      <div class="card card-body">
        <div class="section-title" style="margin-bottom:20px">Cài đặt thông báo</div>
        ${[
          {label:'Thông báo qua Email',desc:'Nhận thông báo qua địa chỉ email',id:'email-notif',checked:true},
          {label:'Thông báo đẩy',desc:'Nhận thông báo trên trình duyệt',id:'push-notif',checked:true},
          {label:'Thông báo khi có phê duyệt',desc:'Nhận thông báo khi có yêu cầu phê duyệt mới',id:'approval-notif',checked:true},
          {label:'Thông báo phản hồi mới',desc:'Nhận thông báo khi có phản hồi mới từ người dùng',id:'feedback-notif',checked:false},
          {label:'Báo cáo tuần',desc:'Nhận tóm tắt hoạt động hàng tuần',id:'weekly-notif',checked:true},
        ].map(n=>`
          <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 0;border-bottom:1px solid var(--gray-100)">
            <div>
              <div style="font-weight:500;font-size:14px">${n.label}</div>
              <div style="font-size:12px;color:var(--gray-500);margin-top:2px">${n.desc}</div>
            </div>
            <label class="switch">
              <input type="checkbox" ${n.checked?'checked':''} onchange="showToast('Đã cập nhật cài đặt','success')">
              <span class="switch-track"></span>
            </label>
          </div>
        `).join('')}
      </div>
    </div>

    <!-- Security Tab -->
    <div class="tab-content" data-tab-content="security">
      <div class="card card-body" style="margin-bottom:16px">
        <div class="section-title" style="margin-bottom:20px">Đổi mật khẩu</div>
        <div class="form-group"><label class="form-label">Mật khẩu hiện tại</label>
          <div class="input-wrap"><input type="password" class="input" placeholder="••••••••">
            <button type="button" class="input-icon-right" onclick="togglePw(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></button>
          </div>
        </div>
        <div class="form-group"><label class="form-label">Mật khẩu mới</label><input type="password" class="input" placeholder="••••••••"></div>
        <div class="form-group"><label class="form-label">Xác nhận mật khẩu mới</label><input type="password" class="input" placeholder="••••••••"></div>
        <button class="btn btn-primary" onclick="showToast('Đã đổi mật khẩu thành công!','success')">Đổi mật khẩu</button>
      </div>
      <div class="card card-body">
        <div style="display:flex;align-items:center;justify-content:space-between">
          <div>
            <div style="font-weight:500;font-size:14px">Xác thực 2 bước (2FA)</div>
            <div style="font-size:12px;color:var(--gray-500);margin-top:2px">Tăng cường bảo mật tài khoản</div>
          </div>
          <label class="switch"><input type="checkbox" onchange="showToast('Đã cập nhật bảo mật','success')"><span class="switch-track"></span></label>
        </div>
      </div>
    </div>

    <!-- Appearance Tab -->
    <div class="tab-content" data-tab-content="appearance">
      <div class="card card-body">
        <div style="display:flex;align-items:center;gap:8px;font-size:16px;font-weight:700;margin-bottom:20px">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>
          Giao diện
        </div>
        <div class="form-label" style="margin-bottom:12px">Giao diện hiển thị</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;max-width:720px" id="theme-sel">
          <div onclick="selectTheme(this,'light')" style="cursor:pointer;border-radius:12px;border:2.5px solid #0ea5e9;overflow:hidden;transition:all .2s" id="t-light">
            <div style="height:90px;background:#f8fafc;border-bottom:1px solid #e2e8f0;position:relative">
              <div style="position:absolute;top:8px;left:8px;right:8px;height:10px;background:#e2e8f0;border-radius:3px"></div>
              <div style="position:absolute;top:26px;left:8px;width:40%;height:8px;background:#cbd5e1;border-radius:3px"></div>
              <div style="position:absolute;top:42px;left:8px;right:8px;height:28px;background:#fff;border-radius:6px;border:1px solid #e2e8f0"></div>
            </div>
            <div style="padding:10px 12px;background:#fff;display:flex;align-items:center;justify-content:space-between">
              <span style="font-size:13px;font-weight:600;color:var(--gray-800)">Sáng</span>
              <div id="t-light-check" style="width:18px;height:18px;border-radius:50%;background:#0ea5e9;display:flex;align-items:center;justify-content:center">
                <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" width="11" height="11"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
            </div>
          </div>
          <div onclick="selectTheme(this,'dark')" style="cursor:pointer;border-radius:12px;border:2px solid #e2e8f0;overflow:hidden;transition:all .2s" id="t-dark">
            <div style="height:90px;background:#1e293b;border-bottom:1px solid #334155;position:relative">
              <div style="position:absolute;top:8px;left:8px;right:8px;height:10px;background:#334155;border-radius:3px"></div>
              <div style="position:absolute;top:26px;left:8px;width:40%;height:8px;background:#475569;border-radius:3px"></div>
              <div style="position:absolute;top:42px;left:8px;right:8px;height:28px;background:#0f172a;border-radius:6px;border:1px solid #334155"></div>
            </div>
            <div style="padding:10px 12px;background:#fff;display:flex;align-items:center;justify-content:space-between">
              <span style="font-size:13px;font-weight:600;color:var(--gray-800)">Tối</span>
              <div id="t-dark-check" style="width:18px;height:18px;border-radius:50%;background:var(--gray-200)"></div>
            </div>
          </div>
          <div onclick="selectTheme(this,'auto')" style="cursor:pointer;border-radius:12px;border:2px solid #e2e8f0;overflow:hidden;transition:all .2s" id="t-auto">
            <div style="height:90px;background:linear-gradient(135deg,#f8fafc 50%,#1e293b 50%);border-bottom:1px solid #e2e8f0;position:relative">
              <div style="position:absolute;top:8px;left:8px;width:45%;height:10px;background:#e2e8f0;border-radius:3px"></div>
              <div style="position:absolute;top:8px;right:8px;width:40%;height:10px;background:#334155;border-radius:3px"></div>
              <div style="position:absolute;top:26px;left:8px;width:35%;height:8px;background:#cbd5e1;border-radius:3px"></div>
              <div style="position:absolute;top:26px;right:8px;width:35%;height:8px;background:#475569;border-radius:3px"></div>
            </div>
            <div style="padding:10px 12px;background:#fff;display:flex;align-items:center;justify-content:space-between">
              <span style="font-size:13px;font-weight:600;color:var(--gray-800)">Tự động</span>
              <div id="t-auto-check" style="width:18px;height:18px;border-radius:50%;background:var(--gray-200)"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
`;

function selectTheme(el, theme) {
  ['light','dark','auto'].forEach(t => {
    const card = document.getElementById('t-'+t);
    const check = document.getElementById('t-'+t+'-check');
    if (t === theme) {
      card.style.border = '2.5px solid #0ea5e9';
      check.style.background = '#0ea5e9';
      check.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" width="11" height="11"><polyline points="20 6 9 17 4 12"/></svg>';
    } else {
      card.style.border = '2px solid #e2e8f0';
      check.style.background = 'var(--gray-200)';
      check.innerHTML = '';
    }
  });
  const names = {light:'Sáng', dark:'Tối', auto:'Tự động'};
  showToast('Đã chọn giao diện: ' + names[theme], 'success');
}
function saveSettings() { showToast('Đã lưu cài đặt thành công!', 'success'); }
function togglePw(btn) {
  const input = btn.previousElementSibling || btn.parentElement.querySelector('input');
  if (input) input.type = input.type === 'password' ? 'text' : 'password';
}

document.addEventListener('DOMContentLoaded', () => initTabs());

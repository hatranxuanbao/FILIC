const favForms = [
  {id:'1',name:'Đăng ký khóa học Tiếng Anh nâng cao',cat:'Đăng ký',responses:1234,modified:'2 giờ trước',rating:5,status:'active',img:'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=400&h=200&fit=crop'},
  {id:'2',name:'Khảo sát mức độ hài lòng học viên',cat:'Khảo sát',responses:987,modified:'5 giờ trước',rating:4,status:'active',img:'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=400&h=200&fit=crop'},
  {id:'3',name:'Đăng ký thi chứng chỉ Tin học',cat:'Đăng ký',responses:756,modified:'1 ngày trước',rating:5,status:'active',img:'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=200&fit=crop'},
  {id:'4',name:'Phiếu đánh giá giảng viên',cat:'Đánh giá',responses:543,modified:'3 ngày trước',rating:4,status:'draft',img:'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400&h=200&fit=crop'},
  {id:'5',name:'Đăng ký học thử miễn phí',cat:'Đăng ký',responses:432,modified:'6 giờ trước',rating:5,status:'active',img:'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400&h=200&fit=crop'},
  {id:'6',name:'Khảo sát nhu cầu mở lớp mới',cat:'Khảo sát',responses:321,modified:'2 ngày trước',rating:3,status:'active',img:'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=400&h=200&fit=crop'},
];

let favFiltered = [...favForms];
const favsBadge = s => s==='active'?'<span class="badge badge-green">Hoạt động</span>':'<span class="badge badge-yellow">Nháp</span>';
const stars = n => Array.from({length:5},(_,i)=>`<svg viewBox="0 0 24 24" fill="${i<n?'#f59e0b':'#e2e8f0'}" width="13" height="13"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`).join('');

document.getElementById('page-content').innerHTML = `
  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between">
    <div><h2 class="page-title">Danh sách yêu thích</h2><p class="page-sub">Các biểu mẫu bạn đã đánh dấu yêu thích</p></div>
    <div style="display:flex;gap:8px;align-items:center">
      <button class="btn btn-outline" onclick="document.getElementById('fav-fp').style.display=document.getElementById('fav-fp').style.display==='none'?'block':'none'">${IC.filter}Lọc</button>
      ${exportDropdown('fav-exp-wrap','fav-exp-menu')}
    </div>
  </div>

  ${filterPanel('fav-fp', [
    {label:'Danh mục', id:'fav-cat', opts:[{v:'all',l:'Tất cả danh mục'},'Đăng ký','Khảo sát','Đánh giá','Phản hồi']},
    {label:'Trạng thái', id:'fav-status', opts:[{v:'all',l:'Tất cả trạng thái'},{v:'active',l:'Hoạt động'},{v:'draft',l:'Nháp'},{v:'archived',l:'Lưu trữ'}]},
    {label:'Từ ngày', type:'date'},
    {label:'Đến ngày', type:'date'},
  ])}

  <div class="card card-body" style="margin-bottom:16px">
    <div class="input-wrap">
      <div class="input-icon">${IC.search}</div>
      <input type="text" id="fav-search" class="input" placeholder="Tìm kiếm form yêu thích..." oninput="searchFav()">
    </div>
  </div>

  <p id="fav-count" style="font-size:13px;color:var(--gray-500);margin-bottom:16px"></p>
  <div class="grid-3" id="fav-grid"></div>
`;

function renderFav(list) {
  document.getElementById('fav-count').innerHTML = `Hiển thị <strong style="color:var(--gray-800)">${list.length}</strong> trong tổng số <strong style="color:var(--gray-800)">${favForms.length}</strong> form`;
  document.getElementById('fav-grid').innerHTML = list.map(f=>`
    <div class="form-card">
      <div class="form-card-thumb">
        <img src="${f.img}" alt="${f.name}" loading="lazy">
        <div class="badge-pos">${favsBadge(f.status)}</div>
        <div style="position:absolute;top:10px;right:10px">
          <button style="width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,.9);display:flex;align-items:center;justify-content:center;box-shadow:0 2px 6px rgba(0,0,0,.2);border:none;cursor:pointer" onclick="removeFav('${f.id}')">
            <svg viewBox="0 0 24 24" fill="#e91e63" stroke="#e91e63" stroke-width="2" width="15" height="15"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
          </button>
        </div>
        <div class="form-card-overlay">
          <button class="btn btn-outline btn-sm" style="background:rgba(255,255,255,.9)" onclick="showToast('Đang xem form...')">${IC.eye}Xem</button>
        </div>
      </div>
      <div class="form-card-body">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
          <span class="badge badge-blue">${f.cat}</span>
          <div style="display:flex;gap:1px">${stars(f.rating)}</div>
        </div>
        <div class="form-card-name">${f.name}</div>
        <div class="form-card-meta" style="margin-top:8px">
          <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>${f.responses.toLocaleString()} phản hồi</span>
          <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>${f.modified}</span>
        </div>
      </div>
    </div>`).join('');
}

function removeFav(id) {
  const idx = favForms.findIndex(f => f.id === id);
  if (idx !== -1) { favForms.splice(idx,1); favFiltered = favFiltered.filter(f=>f.id!==id); renderFav(favFiltered); showToast('Đã xóa khỏi yêu thích','warning'); }
}
function searchFav() {
  const q = document.getElementById('fav-search').value.toLowerCase();
  favFiltered = favForms.filter(f => f.name.toLowerCase().includes(q));
  renderFav(favFiltered);
}
function applyFilter() {
  const cat = document.getElementById('fav-cat').value;
  const status = document.getElementById('fav-status').value;
  favFiltered = favForms.filter(f => (cat==='all'||f.cat===cat) && (status==='all'||f.status===status));
  renderFav(favFiltered);
  showToast(`Đã lọc: ${favFiltered.length} kết quả`,'success');
}
function resetFilter() { favFiltered=[...favForms]; renderFav(favFiltered); showToast('Đã xóa bộ lọc'); }

outsideClick('fav-exp-wrap', 'fav-exp-menu');
renderFav(favFiltered);

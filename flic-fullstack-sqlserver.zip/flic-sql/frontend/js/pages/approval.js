// ── localStorage ─────────────────────────────────────────────────
const LS_APPROVALS = 'flic_approvals';
const DEFAULT_APPROVALS = [
  {id:'1',form:'Đăng ký khóa học Tiếng Anh',by:'Nguyễn Minh Anh',date:'14/03/2026 09:30',status:'pending',cat:'Đăng ký',priority:'high',questions:[
    {id:'q1',text:'Bạn muốn đăng ký khóa học nào?',type:'choice',opts:['Tiếng Anh cơ bản','Tiếng Anh nâng cao','IELTS','TOEIC']},
    {id:'q2',text:'Trình độ hiện tại của bạn?',type:'choice',opts:['Mới bắt đầu','Sơ cấp','Trung cấp','Nâng cao']},
  ]},
  {id:'2',form:'Khảo sát mức độ hài lòng',by:'Trần Văn Bình',date:'13/03/2026 14:15',status:'pending',cat:'Khảo sát',priority:'medium',questions:[
    {id:'q1',text:'Bạn hài lòng như thế nào về chất lượng giảng dạy?',type:'rating',opts:['1 - Rất không hài lòng','2 - Không hài lòng','3 - Bình thường','4 - Hài lòng','5 - Rất hài lòng']},
    {id:'q2',text:'Bạn có giới thiệu FLIC cho người thân không?',type:'choice',opts:['Chắc chắn có','Có thể','Chưa chắc','Không']},
  ]},
  {id:'3',form:'Phiếu đánh giá giảng viên',by:'Lê Thị Cúc',date:'12/03/2026 11:00',status:'approved',cat:'Đánh giá',priority:'low',questions:[
    {id:'q1',text:'Giảng viên có giảng dạy nhiệt tình không?',type:'rating',opts:['1','2','3','4','5']},
  ]},
  {id:'4',form:'Đăng ký thi chứng chỉ Tin học',by:'Phạm Quốc Dũng',date:'11/03/2026 16:45',status:'rejected',cat:'Đăng ký',priority:'high',questions:[
    {id:'q1',text:'Bạn muốn thi chứng chỉ nào?',type:'choice',opts:['IC3','MOS','ICDL']},
  ]},
  {id:'5',form:'Feedback chương trình học',by:'Hoàng Thị Em',date:'10/03/2026 08:20',status:'approved',cat:'Phản hồi',priority:'medium',questions:[
    {id:'q1',text:'Chương trình học có phù hợp không?',type:'rating',opts:['1','2','3','4','5']},
    {id:'q2',text:'Bạn muốn FLIC cải thiện điều gì?',type:'text',opts:[]},
  ]},
  {id:'6',form:'Đăng ký học thử miễn phí',by:'Vũ Minh Phúc',date:'09/03/2026 13:30',status:'pending',cat:'Đăng ký',priority:'high',questions:[
    {id:'q1',text:'Bạn quan tâm đến khóa học nào?',type:'choice',opts:['Tiếng Anh','Tin học','Thiết kế']},
  ]},
];

function loadApprovals() {
  try { const r = localStorage.getItem(LS_APPROVALS); return r ? JSON.parse(r) : DEFAULT_APPROVALS; } catch(e) { return DEFAULT_APPROVALS; }
}
function saveApprovals(list) {
  try { localStorage.setItem(LS_APPROVALS, JSON.stringify(list)); } catch(e) {}
}

let approvalData = loadApprovals();

// ── Helpers ───────────────────────────────────────────────────────
const priorityBadge = p => p==='high'?'<span class="badge badge-red">Cao</span>':p==='medium'?'<span class="badge badge-yellow">Trung bình</span>':'<span class="badge badge-gray">Thấp</span>';
const apprStatusBadge = s => s==='pending'?'<span class="badge badge-yellow">Chờ duyệt</span>':s==='approved'?'<span class="badge badge-green">Đã duyệt</span>':'<span class="badge badge-red">Từ chối</span>';
const typeLabel = t => t==='choice'?'Lựa chọn':t==='rating'?'Đánh giá':'Văn bản';
const typeBadgeColor = t => t==='rating'?'#f59e0b':t==='text'?'#8b5cf6':'#0ea5e9';

function renderApproval(tab) {
  const list = tab === 'all' ? approvalData : approvalData.filter(a => a.status === tab);
  document.getElementById('approval-tbody').innerHTML = list.length === 0
    ? `<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--gray-400)">Không có dữ liệu</td></tr>`
    : list.map(a => `
    <tr>
      <td><div style="font-weight:500;color:var(--gray-900)">${a.form}</div><div style="font-size:12px;color:var(--gray-400)">${a.cat}</div></td>
      <td>${a.by}</td>
      <td style="font-size:12px;color:var(--gray-500)">${a.date}</td>
      <td>${priorityBadge(a.priority)}</td>
      <td>${apprStatusBadge(a.status)}</td>
      <td>
        <div style="display:flex;gap:6px;align-items:center">
          ${a.status==='pending'?`
            <button class="btn btn-sm" style="background:#dcfce7;color:#166534" onclick="approveItem('${a.id}')">${IC.check}Duyệt</button>
            <button class="btn btn-sm" style="background:#fee2e2;color:#991b1b" onclick="rejectItem('${a.id}')">${IC.reject}Từ chối</button>
          `:''}
          ${a.status==='approved'?`
            <button class="btn btn-sm" style="background:#e0f2fe;color:#0284c7" onclick="openShareModal('${a.id}','${a.form.replace(/'/g,"\\'")}')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>Chia sẻ
            </button>
          `:''}
          <button class="icon-btn" title="Xem câu hỏi" onclick="openViewModal('${a.id}')">${IC.eye}</button>
        </div>
      </td>
    </tr>`).join('');
  updateTabCounts();
}

function updateTabCounts() {
  const pending = approvalData.filter(a=>a.status==='pending').length;
  const el = document.querySelector('.tab-btn[data-tab="pending"] .badge');
  if (el) el.textContent = pending;
}

function approveItem(id) {
  const item = approvalData.find(a => a.id === id);
  if (!item) return;
  item.status = 'approved';
  saveApprovals(approvalData);
  renderApproval('all');
  showToast('Đã phê duyệt thành công!','success');
}
function rejectItem(id) {
  const item = approvalData.find(a => a.id === id);
  if (!item) return;
  item.status = 'rejected';
  saveApprovals(approvalData);
  renderApproval('all');
  showToast('Đã từ chối yêu cầu!','error');
}

function applyFilter() { showToast('Đã áp dụng bộ lọc','success'); }
function resetFilter() { showToast('Đã xóa bộ lọc'); }

// ── View questions modal ──────────────────────────────────────────
function openViewModal(id) {
  const item = approvalData.find(a => a.id === id);
  if (!item) return;
  const qs = item.questions || [];
  document.getElementById('view-modal-title').textContent = item.form;
  document.getElementById('view-modal-cat').textContent = item.cat + ' • ' + qs.length + ' câu hỏi';
  document.getElementById('view-modal-questions').innerHTML = qs.length === 0
    ? '<div style="text-align:center;padding:32px;color:var(--gray-400)">Không có câu hỏi nào</div>'
    : qs.map((q, i) => `
      <div style="border:1px solid var(--gray-200);border-radius:var(--radius-lg);padding:16px;margin-bottom:12px">
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:${q.opts&&q.opts.length?'12px':'0'}">
          <div style="width:24px;height:24px;border-radius:50%;background:#e0f2fe;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:#0284c7;flex-shrink:0">${i+1}</div>
          <div style="flex:1">
            <div style="font-size:14px;font-weight:600;color:var(--gray-900);margin-bottom:6px">${q.text}</div>
            <span style="font-size:11px;font-weight:600;padding:2px 8px;border-radius:4px;background:${typeBadgeColor(q.type)}20;color:${typeBadgeColor(q.type)}">${typeLabel(q.type)}</span>
          </div>
        </div>
        ${q.opts&&q.opts.length?`
          <div style="margin-left:34px;display:flex;flex-wrap:wrap;gap:6px">
            ${q.opts.map(o=>`<span style="background:#f8f9fb;border:1px solid var(--gray-200);border-radius:6px;padding:4px 10px;font-size:12.5px;color:var(--gray-600)">${o}</span>`).join('')}
          </div>`:''}
      </div>`).join('');
  openModal('view-modal');
}

// ── Share modal ───────────────────────────────────────────────────
const SHARE_LINK = 'https://flic.edu.vn/forms/';
function openShareModal(id, formName) {
  document.getElementById('share-form-name').textContent = formName;
  document.getElementById('share-link-input').value = SHARE_LINK + id;
  document.getElementById('share-copied-msg').style.display = 'none';
  openModal('share-modal');
}
function copyShareLink() {
  const input = document.getElementById('share-link-input');
  navigator.clipboard.writeText(input.value).then(() => {
    document.getElementById('share-copied-msg').style.display = 'flex';
    setTimeout(() => document.getElementById('share-copied-msg').style.display = 'none', 2500);
  }).catch(() => { input.select(); document.execCommand('copy'); showToast('Đã sao chép!','success'); });
}

// ── Page HTML ─────────────────────────────────────────────────────
document.getElementById('page-content').innerHTML = `
  <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
    <div><h2 class="page-title">Quản lý phê duyệt</h2><p class="page-sub">Xem xét và phê duyệt các yêu cầu từ nhân viên</p></div>
    <div style="display:flex;gap:8px;align-items:center">
      <button class="btn btn-outline" onclick="document.getElementById('appr-fp').style.display=document.getElementById('appr-fp').style.display==='none'?'block':'none'">${IC.filter}Lọc</button>
      ${exportDropdown('appr-exp-wrap','appr-exp-menu')}
    </div>
  </div>

  ${filterPanel('appr-fp', [
    {label:'Danh mục', opts:['Tất cả danh mục','Đăng ký','Khảo sát','Đánh giá']},
    {label:'Trạng thái', opts:['Tất cả trạng thái','Chờ duyệt','Đã duyệt','Từ chối']},
    {label:'Từ ngày', type:'date'},
    {label:'Đến ngày', type:'date'},
  ])}

  <div class="grid-4" style="margin-bottom:24px">
    ${statCard('Chờ phê duyệt','8','#f59e0b','#fef9c3','<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>')}
    ${statCard('Đã phê duyệt','142','#10b981','#dcfce7','<path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>')}
    ${statCard('Từ chối','23','#ef4444','#fee2e2','<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>')}
    ${statCard('Tổng yêu cầu','173','#0ea5e9','#e0f2fe','<path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>')}
  </div>

  <div class="card card-body" style="margin-bottom:20px">
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <div class="input-wrap" style="flex:1;min-width:200px">
        <div class="input-icon">${IC.search}</div>
        <input type="text" class="input" placeholder="Tìm kiếm yêu cầu...">
      </div>
      <select class="input" style="width:auto"><option>Tất cả ưu tiên</option><option>Cao</option><option>Trung bình</option><option>Thấp</option></select>
    </div>
  </div>

  <div data-tabs>
    <div class="tabs">
      <button class="tab-btn active" data-tab="all" onclick="renderApproval('all')">Tất cả</button>
      <button class="tab-btn" data-tab="pending" onclick="renderApproval('pending')">Chờ duyệt <span class="badge badge-yellow" style="margin-left:4px">0</span></button>
      <button class="tab-btn" data-tab="approved" onclick="renderApproval('approved')">Đã duyệt</button>
      <button class="tab-btn" data-tab="rejected" onclick="renderApproval('rejected')">Từ chối</button>
    </div>
    <div class="card">
      <div class="table-wrap">
        <table>
          <thead><tr><th>Biểu mẫu</th><th>Người gửi</th><th>Ngày gửi</th><th>Ưu tiên</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
          <tbody id="approval-tbody"></tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- View Questions Modal -->
  <div class="modal-overlay" id="view-modal">
    <div class="modal" onclick="event.stopPropagation()" style="max-width:560px">
      <div class="modal-header">
        <div>
          <div class="modal-title" id="view-modal-title"></div>
          <div style="font-size:12.5px;color:var(--gray-400);margin-top:2px" id="view-modal-cat"></div>
        </div>
        <button class="icon-btn close-btn" onclick="closeModal('view-modal')">${IC.close}</button>
      </div>
      <div class="modal-body" style="max-height:65vh;overflow-y:auto" id="view-modal-questions"></div>
      <div class="modal-footer">
        <button class="btn btn-outline" onclick="closeModal('view-modal')">Đóng</button>
      </div>
    </div>
  </div>

  <!-- Share Modal -->
  <div class="modal-overlay" id="share-modal">
    <div class="modal" onclick="event.stopPropagation()" style="max-width:480px">
      <div class="modal-header">
        <div>
          <div class="modal-title">Chia sẻ biểu mẫu</div>
          <div style="font-size:12.5px;color:var(--gray-400);margin-top:2px" id="share-form-name"></div>
        </div>
        <button class="icon-btn close-btn" onclick="closeModal('share-modal')">${IC.close}</button>
      </div>
      <div class="modal-body">
        <div style="margin-bottom:20px">
          <label class="form-label" style="margin-bottom:8px">Thêm người, nhóm</label>
          <input type="text" class="input" placeholder="Nhập email để thêm...">
        </div>
        <div style="font-size:13.5px;font-weight:700;color:var(--gray-700);margin-bottom:12px">Những người có quyền truy cập</div>
        <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:20px">
          <div style="display:flex;align-items:center;gap:10px">
            <div style="width:36px;height:36px;border-radius:50%;background:#0ea5e9;display:flex;align-items:center;justify-content:center;color:#fff;font-size:13px;font-weight:700;flex-shrink:0">A</div>
            <div style="flex:1"><div style="font-size:13.5px;font-weight:600">Nguyễn Văn A (bạn)</div><div style="font-size:12px;color:var(--gray-400)">nguyenvana@flic.edu.vn</div></div>
            <span style="font-size:13px;color:var(--gray-400)">Chủ sở hữu</span>
          </div>
          <div style="display:flex;align-items:center;gap:10px">
            <div style="width:36px;height:36px;border-radius:50%;background:#8b5cf6;display:flex;align-items:center;justify-content:center;color:#fff;font-size:13px;font-weight:700;flex-shrink:0">T</div>
            <div style="flex:1"><div style="font-size:13.5px;font-weight:600">Nguyễn Thị T</div><div style="font-size:12px;color:var(--gray-400)">thuynt.it@flic.edu.vn</div></div>
            <select class="input" style="width:auto;font-size:12.5px;padding:4px 8px"><option>Người chỉnh sửa</option><option>Người xem</option></select>
          </div>
        </div>
        <div style="background:var(--gray-50);border:1px solid var(--gray-200);border-radius:var(--radius-lg);padding:14px 16px;margin-bottom:16px">
          <div style="font-size:13.5px;font-weight:700;color:var(--gray-700);margin-bottom:10px">Quyền truy cập chung</div>
          <div style="display:flex;align-items:center;gap:12px">
            <div style="width:36px;height:36px;border-radius:50%;background:#dcfce7;display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <svg viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="2" width="18" height="18"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>
            </div>
            <div style="flex:1">
              <select class="input" style="width:auto;font-size:13px;font-weight:600;padding:4px 8px;margin-bottom:4px"><option>Bất kỳ ai có đường liên kết</option><option>Chỉ người được thêm</option></select>
              <div style="font-size:12px;color:var(--gray-500)">Bất kỳ ai có liên kết đều có thể truy cập</div>
            </div>
            <select class="input" style="width:auto;font-size:12.5px;padding:4px 8px"><option>Người xem</option><option>Người chỉnh sửa</option></select>
          </div>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <div class="input-wrap" style="flex:1">
            <input type="text" id="share-link-input" class="input" readonly style="background:#f8f9fb;font-size:12.5px;color:var(--gray-600);cursor:default">
          </div>
          <button class="btn btn-primary" onclick="copyShareLink()" style="white-space:nowrap;flex-shrink:0">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>Sao chép liên kết
          </button>
        </div>
        <div id="share-copied-msg" style="display:none;align-items:center;gap:6px;margin-top:8px;font-size:12.5px;color:#16a34a;font-weight:600">
          <svg viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="2.5" width="14" height="14"><path d="M20 6L9 17l-5-5"/></svg>Đã sao chép đường liên kết!
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline" onclick="closeModal('share-modal')">Đóng</button>
        <button class="btn btn-primary" onclick="closeModal('share-modal');showToast('Đã gửi lời mời chia sẻ!','success')">Xong</button>
      </div>
    </div>
  </div>
`;

renderApproval('all');
outsideClick('appr-exp-wrap', 'appr-exp-menu');

// backend/seed.js
// Tạo dữ liệu mẫu ban đầu

require('dotenv').config();
const mongoose = require('mongoose');
const User     = require('./models/User');
const Form     = require('./models/Form');

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Kết nối MongoDB thành công');

    // Xóa dữ liệu cũ
    await User.deleteMany({});
    await Form.deleteMany({});
    console.log('🗑️  Đã xóa dữ liệu cũ');

    // Tạo tài khoản mặc định
    const users = await User.insertMany([
      {
        tenDangNhap: 'admin',
        matKhau:     '123456',
        hoTen:       'Nguyễn Văn A',
        email:       'admin@flic.edu.vn',
        soDienThoai: '0912345678',
        phongBan:    'Quản lý hệ thống',
        vaiTro:      'admin',
        trangThai:   'active',
      },
      {
        tenDangNhap: 'manager',
        matKhau:     '123456',
        hoTen:       'Trần Thị B',
        email:       'tranthib@flic.edu.vn',
        soDienThoai: '0923456789',
        phongBan:    'Phòng Ngoại ngữ',
        vaiTro:      'quanly',
        trangThai:   'active',
      },
      {
        tenDangNhap: 'staff',
        matKhau:     '123456',
        hoTen:       'Lê Văn C',
        email:       'levanc@flic.edu.vn',
        soDienThoai: '0934567890',
        phongBan:    'Phòng Tin học',
        vaiTro:      'nhanvien',
        trangThai:   'active',
      },
    ]);
    console.log(`👥 Đã tạo ${users.length} tài khoản`);

    // Tạo form mẫu
    const adminUser = users[0];
    const forms = await Form.insertMany([
      {
        tenFormMau: 'Đăng ký khóa học Tiếng Anh giao tiếp',
        moTa:       'Form đăng ký các khóa học tiếng Anh từ cơ bản đến nâng cao',
        danhMuc:    'Đăng ký',
        nguoiTao:   adminUser._id,
        trangThai:  'active',
        mauSac:     '#0ea5e9',
        cauHoi: [
          { noiDung: 'Họ và tên', loaiCauHoi: 'text', batBuoc: true, thuTu: 1 },
          { noiDung: 'Địa chỉ email', loaiCauHoi: 'email', batBuoc: true, thuTu: 2 },
          { noiDung: 'Số điện thoại', loaiCauHoi: 'phone', batBuoc: true, thuTu: 3 },
          { noiDung: 'Trình độ hiện tại', loaiCauHoi: 'dropdown', batBuoc: true, thuTu: 4,
            tuyChon: ['Mất gốc', 'Cơ bản', 'Trung cấp', 'Nâng cao'] },
          { noiDung: 'Buổi học mong muốn', loaiCauHoi: 'radio', batBuoc: false, thuTu: 5,
            tuyChon: ['Sáng', 'Chiều', 'Tối'] },
        ],
      },
      {
        tenFormMau: 'Khảo sát mức độ hài lòng học viên',
        moTa:       'Thu thập ý kiến phản hồi từ học viên về chất lượng giảng dạy',
        danhMuc:    'Khảo sát',
        nguoiTao:   users[1]._id,
        trangThai:  'active',
        mauSac:     '#8b5cf6',
        cauHoi: [
          { noiDung: 'Chất lượng giảng dạy', loaiCauHoi: 'rating', batBuoc: true, thuTu: 1 },
          { noiDung: 'Cơ sở vật chất', loaiCauHoi: 'rating', batBuoc: true, thuTu: 2 },
          { noiDung: 'Điều bạn hài lòng nhất', loaiCauHoi: 'checkbox', batBuoc: false, thuTu: 3,
            tuyChon: ['Giảng viên', 'Học liệu', 'Lịch học', 'Học phí'] },
          { noiDung: 'Góp ý thêm', loaiCauHoi: 'textarea', batBuoc: false, thuTu: 4 },
        ],
      },
    ]);
    console.log(`📋 Đã tạo ${forms.length} form mẫu`);

    console.log('\n✅ Seed dữ liệu hoàn tất!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('Tài khoản mặc định:');
    console.log('  admin   / 123456  (Quản trị viên)');
    console.log('  manager / 123456  (Quản lý)');
    console.log('  staff   / 123456  (Nhân viên)');

    process.exit(0);
  } catch (err) {
    console.error('❌ Lỗi seed:', err);
    process.exit(1);
  }
}

seed();

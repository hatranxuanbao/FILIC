// backend/routes/auth.js
const express = require('express');
const jwt     = require('jsonwebtoken');
const bcrypt  = require('bcryptjs');
const { query, sql } = require('../config/database');
const { protect } = require('../middleware/auth');

const router = express.Router();

const taoToken = (maTK) =>
  jwt.sign({ id: maTK }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password)
      return res.status(400).json({ error: 'Vui lòng nhập tên đăng nhập và mật khẩu.' });

    const r = await query(
      'SELECT * FROM dbo.TaiKhoan WHERE TenDangNhap = @u',
      { u: username }
    );
    const user = r.recordset[0];

    if (!user)
      return res.status(401).json({ error: 'Sai tên đăng nhập hoặc mật khẩu.' });

    // So sánh mật khẩu (hỗ trợ cả bcrypt và plain text)
    let dungMatKhau = false;
    if (user.MatKhau.startsWith('$2')) {
      dungMatKhau = await bcrypt.compare(password, user.MatKhau);
    } else {
      dungMatKhau = password === user.MatKhau;
    }

    if (!dungMatKhau)
      return res.status(401).json({ error: 'Sai tên đăng nhập hoặc mật khẩu.' });

    if (user.TrangThai === 'inactive')
      return res.status(403).json({ error: 'Tài khoản đã bị vô hiệu hóa.' });

    const token = taoToken(user.MaTK);
    const { MatKhau, ...safe } = user;

    res.json({
      success: true,
      token,
      user: {
        id:          safe.MaTK,
        MaTK:        safe.MaTK,
        TenDangNhap: safe.TenDangNhap,
        HoTen:       safe.HoTen,
        Email:       safe.Email,
        VaiTro:      safe.VaiTro,
        PhongBan:    safe.PhongBan,
        TrangThai:   safe.TrangThai,
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Lỗi server.' });
  }
});

// POST /api/auth/forgot-password
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    const r = await query('SELECT MaTK FROM dbo.TaiKhoan WHERE Email = @email', { email });
    if (!r.recordset.length)
      return res.status(404).json({ error: 'Email không tồn tại.' });
    res.json({ success: true, message: `Email khôi phục đã gửi tới ${email}` });
  } catch (err) {
    res.status(500).json({ error: 'Lỗi server.' });
  }
});

// GET /api/auth/me
router.get('/me', protect, async (req, res) => {
  res.json({ success: true, user: req.user });
});

module.exports = router;

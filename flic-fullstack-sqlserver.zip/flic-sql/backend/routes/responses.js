// backend/routes/responses.js
const express = require('express');
const { query, sql } = require('../config/database');
const { protect } = require('../middleware/auth');

const router = express.Router();

async function nextId(table, pkCol, prefix) {
  const r = await query(
    `SELECT ISNULL(MAX(CAST(SUBSTRING(${pkCol}, ${prefix.length+1}, 10) AS INT)), 0) + 1 AS next FROM dbo.${table}`
  );
  return prefix + String(r.recordset[0].next).padStart(3, '0');
}

// POST /api/responses/submit — Khách hàng gửi form (không cần login)
router.post('/submit', async (req, res) => {
  try {
    const { formId, nguoiGui, cauTraLoi, danhGia, camXuc } = req.body;

    // Kiểm tra form
    const fks = await query('SELECT TrangThai FROM dbo.FormKhaoSat WHERE MaForm = @id', { id: formId });
    if (!fks.recordset.length) return res.status(404).json({ error: 'Form không tồn tại.' });
    if (fks.recordset[0].TrangThai !== 'active') return res.status(400).json({ error: 'Form đã đóng.' });

    // Tạo/tìm khách hàng
    let maKH;
    const khCheck = await query('SELECT MaKH FROM dbo.KhachHang WHERE Email = @email', { email: nguoiGui?.email || '' });
    if (khCheck.recordset.length) {
      maKH = khCheck.recordset[0].MaKH;
    } else {
      maKH = await nextId('KhachHang', 'MaKH', 'KH');
      await query(
        'INSERT INTO dbo.KhachHang (MaKH, HoTen, Email, SoDienThoai) VALUES (@MaKH, @HoTen, @Email, @SDT)',
        {
          MaKH, HoTen: { type: sql.NVarChar, value: nguoiGui?.hoTen || 'Ẩn danh' },
          Email: nguoiGui?.email || '', SDT: nguoiGui?.soDienThoai || '',
        }
      );
    }

    // Tạo phản hồi
    const MaPH = await nextId('PhanHoi', 'MaPH', 'PH');
    await query(
      `INSERT INTO dbo.PhanHoi (MaPH, MaForm, MaKH, DanhGia, CamXuc, TrangThai)
       VALUES (@MaPH, @MaForm, @MaKH, @DanhGia, @CamXuc, 'new')`,
      { MaPH, MaForm: formId, MaKH: maKH, DanhGia: danhGia || null, CamXuc: camXuc || 'neutral' }
    );

    // Lưu câu trả lời
    if (Array.isArray(cauTraLoi)) {
      for (const ct of cauTraLoi) {
        const MaCTPH = await nextId('ChiTietPhanHoi', 'MaCTPH', 'CTPH');
        await query(
          'INSERT INTO dbo.ChiTietPhanHoi (MaCTPH, MaPH, MaCH, CauTraLoi) VALUES (@MaCTPH, @MaPH, @MaCH, @CauTraLoi)',
          { MaCTPH, MaPH, MaCH: ct.maCH, CauTraLoi: { type: sql.NVarChar, value: String(ct.giaTri || '') } }
        );
      }
    }

    // Tăng lượt phản hồi
    await query('UPDATE dbo.FormKhaoSat SET SoLuotPhanHoi = SoLuotPhanHoi + 1 WHERE MaForm = @id', { id: formId });

    res.status(201).json({ success: true, MaPH });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Routes cần login
router.use(protect);

// GET /api/responses
router.get('/', async (req, res) => {
  try {
    const { trangthai, camxuc } = req.query;
    let where = 'WHERE 1=1';
    const params = {};
    if (trangthai && trangthai !== 'all') { where += ' AND TrangThai = @ts'; params.ts = trangthai; }
    if (camxuc    && camxuc    !== 'all') { where += ' AND CamXuc = @cx';    params.cx = camxuc; }

    const r = await query(`SELECT * FROM dbo.vw_PhanHoi ${where} ORDER BY ThoiGian DESC`, params);
    res.json({ success: true, responses: r.recordset });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/responses/:id
router.put('/:id', async (req, res) => {
  try {
    await query('UPDATE dbo.PhanHoi SET TrangThai = @ts WHERE MaPH = @id',
      { id: req.params.id, ts: req.body.trangThai });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/responses/:id
router.delete('/:id', async (req, res) => {
  try {
    await query('DELETE FROM dbo.PhanHoi WHERE MaPH = @id', { id: req.params.id });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

// backend/routes/forms.js
const express = require('express');
const { query, sql } = require('../config/database');
const { protect } = require('../middleware/auth');

const router = express.Router();
router.use(protect);

// Tạo mã tự tăng
async function nextId(table, pkCol, prefix) {
  const r = await query(
    `SELECT ISNULL(MAX(CAST(SUBSTRING(${pkCol}, ${prefix.length+1}, 10) AS INT)), 0) + 1 AS next FROM dbo.${table}`
  );
  return prefix + String(r.recordset[0].next).padStart(3, '0');
}

// GET /api/forms
router.get('/', async (req, res) => {
  try {
    const { search, danhmuc, trangthai } = req.query;
    let where = 'WHERE 1=1';
    const params = {};

    if (search) {
      where += ' AND TenFormMau LIKE @search';
      params.search = { type: sql.NVarChar, value: `%${search}%` };
    }
    if (danhmuc    && danhmuc    !== 'all') { where += ' AND DanhMuc = @danhmuc';       params.danhmuc    = { type: sql.NVarChar, value: danhmuc }; }
    if (trangthai  && trangthai  !== 'all') { where += ' AND TrangThai = @trangthai';   params.trangthai  = trangthai; }

    const r = await query(`SELECT * FROM dbo.vw_FormMau ${where} ORDER BY NgayTao DESC`, params);

    // Lấy câu hỏi cho mỗi form
    const forms = await Promise.all(r.recordset.map(async f => {
      const ch = await query('SELECT * FROM dbo.CauHoi WHERE MaFormMau = @id ORDER BY ThuTu', { id: f.MaFormMau });
      return { ...f, cauHoi: ch.recordset };
    }));

    res.json({ success: true, total: forms.length, forms });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/forms/:id
router.get('/:id', async (req, res) => {
  try {
    const fm = await query('SELECT * FROM dbo.vw_FormMau WHERE MaFormMau = @id', { id: req.params.id });
    if (!fm.recordset.length) return res.status(404).json({ error: 'Không tìm thấy form.' });
    const ch = await query('SELECT * FROM dbo.CauHoi WHERE MaFormMau = @id ORDER BY ThuTu', { id: req.params.id });
    // Tăng lượt xem
    await query('UPDATE dbo.FormMau SET SoLuotXem = SoLuotXem + 1 WHERE MaFormMau = @id', { id: req.params.id });
    res.json({ success: true, form: { ...fm.recordset[0], cauHoi: ch.recordset } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/forms
router.post('/', async (req, res) => {
  try {
    const { tenFormMau, moTa, danhMuc, trangThai, cauHoi, mauSac, thumbnailUrl } = req.body;
    if (!tenFormMau) return res.status(400).json({ error: 'Tên form là bắt buộc.' });

    const MaFormMau = await nextId('FormMau', 'MaFormMau', 'FM');
    await query(
      `INSERT INTO dbo.FormMau (MaFormMau, TenFormMau, MoTa, MaTK, TrangThai, DanhMuc, MauSac, ThumbnailUrl)
       VALUES (@MaFormMau, @TenFormMau, @MoTa, @MaTK, @TrangThai, @DanhMuc, @MauSac, @ThumbnailUrl)`,
      {
        MaFormMau,
        TenFormMau:   { type: sql.NVarChar, value: tenFormMau },
        MoTa:         { type: sql.NVarChar, value: moTa || '' },
        MaTK:         req.user.MaTK || req.user.id,
        TrangThai:    trangThai || 'draft',
        DanhMuc:      { type: sql.NVarChar, value: danhMuc || 'Đăng ký' },
        MauSac:       mauSac || '#0ea5e9',
        ThumbnailUrl: thumbnailUrl || '',
      }
    );

    // Lưu câu hỏi nếu có
    if (Array.isArray(cauHoi)) {
      for (let i = 0; i < cauHoi.length; i++) {
        const ch = cauHoi[i];
        const MaCH = await nextId('CauHoi', 'MaCH', 'CH');
        await query(
          `INSERT INTO dbo.CauHoi (MaCH, MaFormMau, LoaiCauHoi, NoiDung, BatBuoc, ThuTu, TuyChon)
           VALUES (@MaCH, @MaFormMau, @LoaiCauHoi, @NoiDung, @BatBuoc, @ThuTu, @TuyChon)`,
          {
            MaCH, MaFormMau,
            LoaiCauHoi: ch.loaiCauHoi || ch.type || 'text',
            NoiDung:    { type: sql.NVarChar, value: ch.noiDung || ch.text || '' },
            BatBuoc:    ch.batBuoc !== false ? 1 : 0,
            ThuTu:      i + 1,
            TuyChon:    ch.tuyChon ? JSON.stringify(ch.tuyChon) : null,
          }
        );
      }
    }

    const form = await query('SELECT * FROM dbo.FormMau WHERE MaFormMau = @id', { id: MaFormMau });
    res.status(201).json({ success: true, form: form.recordset[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/forms/:id
router.put('/:id', async (req, res) => {
  try {
    const { tenFormMau, trangThai, danhMuc, moTa } = req.body;
    await query(
      `UPDATE dbo.FormMau SET
        TenFormMau  = ISNULL(@TenFormMau, TenFormMau),
        TrangThai   = ISNULL(@TrangThai, TrangThai),
        DanhMuc     = ISNULL(@DanhMuc, DanhMuc),
        MoTa        = ISNULL(@MoTa, MoTa),
        NgayCapNhat = GETDATE()
       WHERE MaFormMau = @id`,
      {
        id: req.params.id,
        TenFormMau: { type: sql.NVarChar, value: tenFormMau || null },
        TrangThai:  trangThai || null,
        DanhMuc:    { type: sql.NVarChar, value: danhMuc || null },
        MoTa:       { type: sql.NVarChar, value: moTa    || null },
      }
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/forms/:id
router.delete('/:id', async (req, res) => {
  try {
    await query('DELETE FROM dbo.FormMau WHERE MaFormMau = @id', { id: req.params.id });
    res.json({ success: true, message: 'Đã xóa form.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

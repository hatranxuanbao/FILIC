// backend/routes/users.js
const express = require('express');
const bcrypt  = require('bcryptjs');
const { query, sql } = require('../config/database');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(protect);

async function nextId() {
  const r = await query(
    `SELECT ISNULL(MAX(CAST(SUBSTRING(MaTK, 3, 10) AS INT)), 0) + 1 AS next FROM dbo.TaiKhoan`
  );
  return 'TK' + String(r.recordset[0].next).padStart(3, '0');
}

// GET /api/users
router.get('/', async (req, res) => {
  try {
    const { search, vaitro, trangthai } = req.query;
    let where = 'WHERE 1=1';
    const params = {};

    if (search) {
      where += ' AND (HoTen LIKE @search OR Email LIKE @search)';
      params.search = { type: sql.NVarChar, value: `%${search}%` };
    }
    if (vaitro    && vaitro    !== 'all') { where += ' AND VaiTro = @vaitro';       params.vaitro    = vaitro; }
    if (trangthai && trangthai !== 'all') { where += ' AND TrangThai = @trangthai'; params.trangthai = trangthai; }

    const r = await query(
      `SELECT MaTK, TenDangNhap, VaiTro, HoTen, Email, SoDienThoai, PhongBan, TrangThai, NgayTao
       FROM dbo.TaiKhoan ${where} ORDER BY NgayTao DESC`,
      params
    );
    res.json({ success: true, users: r.recordset });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/users
router.post('/', authorize('admin', 'quanly'), async (req, res) => {
  try {
    const { tenDangNhap, matKhau, hoTen, email, soDienThoai, phongBan, vaiTro } = req.body;

    // Kiểm tra trùng
    const check = await query(
      'SELECT MaTK FROM dbo.TaiKhoan WHERE TenDangNhap = @u OR Email = @e',
      { u: tenDangNhap, e: email }
    );
    if (check.recordset.length)
      return res.status(409).json({ error: 'Tên đăng nhập hoặc email đã tồn tại.' });

    // Mã hóa mật khẩu
    const hashedPw = await bcrypt.hash(matKhau || '123456', 10);
    const MaTK    = await nextId();

    await query(
      `INSERT INTO dbo.TaiKhoan (MaTK, TenDangNhap, MatKhau, VaiTro, HoTen, Email, SoDienThoai, PhongBan)
       VALUES (@MaTK, @TenDangNhap, @MatKhau, @VaiTro, @HoTen, @Email, @SoDienThoai, @PhongBan)`,
      {
        MaTK,
        TenDangNhap: tenDangNhap,
        MatKhau:     hashedPw,
        VaiTro:      vaiTro  || 'nhanvien',
        HoTen:       { type: sql.NVarChar, value: hoTen || '' },
        Email:       email || '',
        SoDienThoai: soDienThoai || '',
        PhongBan:    { type: sql.NVarChar, value: phongBan || 'Chưa phân công' },
      }
    );

    res.status(201).json({ success: true, user: { MaTK, TenDangNhap: tenDangNhap, HoTen: hoTen, Email: email, VaiTro: vaiTro } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/users/:id
router.put('/:id', async (req, res) => {
  try {
    const { hoTen, email, soDienThoai, phongBan, vaiTro, trangThai } = req.body;
    await query(
      `UPDATE dbo.TaiKhoan SET
        HoTen       = ISNULL(@HoTen, HoTen),
        Email       = ISNULL(@Email, Email),
        SoDienThoai = ISNULL(@SoDienThoai, SoDienThoai),
        PhongBan    = ISNULL(@PhongBan, PhongBan),
        VaiTro      = ISNULL(@VaiTro, VaiTro),
        TrangThai   = ISNULL(@TrangThai, TrangThai)
       WHERE MaTK = @id`,
      {
        id: req.params.id,
        HoTen:       { type: sql.NVarChar, value: hoTen    || null },
        Email:       email       || null,
        SoDienThoai: soDienThoai || null,
        PhongBan:    { type: sql.NVarChar, value: phongBan || null },
        VaiTro:      vaiTro      || null,
        TrangThai:   trangThai   || null,
      }
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/users/:id
router.delete('/:id', authorize('admin'), async (req, res) => {
  try {
    await query('DELETE FROM dbo.TaiKhoan WHERE MaTK = @id', { id: req.params.id });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

// backend/routes/dashboard.js
const express = require('express');
const { query } = require('../config/database');
const { protect } = require('../middleware/auth');

const router = express.Router();
router.use(protect);

// GET /api/dashboard/stats
router.get('/stats', async (req, res) => {
  try {
    const r = await query('SELECT * FROM dbo.vw_DashboardStats');
    const s = r.recordset[0];

    // Form gần đây
    const recentR = await query('SELECT TOP 3 * FROM dbo.vw_FormMau ORDER BY NgayTao DESC');

    // Phản hồi theo tuần
    const wr = await query(`
      SELECT DATENAME(dw, ThoiGian) AS day, COUNT(*) AS value
      FROM dbo.PhanHoi
      WHERE ThoiGian >= DATEADD(day, -7, GETDATE())
      GROUP BY DATENAME(dw, ThoiGian), DATEPART(dw, ThoiGian)
      ORDER BY DATEPART(dw, ThoiGian)
    `);

    res.json({
      success: true,
      stats: {
        totalForms:     s.TongFormMau,
        activeForms:    s.FormDangHoatDong,
        totalResponses: s.TongPhanHoi,
        newFeedback:    s.PhanHoiMoi,
        totalStaff:     s.TongNhanVien,
        completionRate: '87.5%',
        recentForms:    recentR.recordset,
        weeklyData:     wr.recordset,
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

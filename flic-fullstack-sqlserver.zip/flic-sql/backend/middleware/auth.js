// backend/middleware/auth.js
const jwt   = require('jsonwebtoken');
const { query } = require('../config/database');

const protect = async (req, res, next) => {
  let token;
  if (req.headers.authorization?.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }
  if (!token) return res.status(401).json({ error: 'Chưa đăng nhập.' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const r = await query(
      'SELECT MaTK, TenDangNhap, HoTen, Email, VaiTro, PhongBan, TrangThai FROM dbo.TaiKhoan WHERE MaTK = @id',
      { id: decoded.id }
    );
    if (!r.recordset.length) return res.status(401).json({ error: 'Tài khoản không tồn tại.' });
    const user = r.recordset[0];
    if (user.TrangThai === 'inactive') return res.status(403).json({ error: 'Tài khoản bị vô hiệu hóa.' });
    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: 'Token không hợp lệ.' });
  }
};

const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.VaiTro)) {
    return res.status(403).json({ error: 'Không có quyền thực hiện.' });
  }
  next();
};

module.exports = { protect, authorize };

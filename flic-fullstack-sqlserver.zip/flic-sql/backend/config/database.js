// backend/config/database.js
// Kết nối SQL Server bằng mssql

const sql = require('mssql');

const config = {
  server:   process.env.DB_SERVER   || 'localhost',
  database: process.env.DB_NAME     || 'FLIC_DB',
  user:     process.env.DB_USER     || 'filic_user',
  password: process.env.DB_PASSWORD || 'Flic@2026',
  port:     parseInt(process.env.DB_PORT) || 1433,
  options: {
    encrypt:                false,
    trustServerCertificate: true,
    enableArithAbort:       true,
  },
  pool: { max: 10, min: 0, idleTimeoutMillis: 30000 },
};

let pool = null;

// Lấy connection pool (tạo mới nếu chưa có)
async function getPool() {
  if (!pool) {
    pool = await sql.connect(config);
    console.log('✅ SQL Server kết nối thành công — DB:', config.database);
  }
  return pool;
}

// Chạy câu lệnh SQL
async function query(sqlText, params = {}) {
  const p   = await getPool();
  const req = p.request();
  for (const [key, val] of Object.entries(params)) {
    if (val !== null && val !== undefined && typeof val === 'object' && 'type' in val) {
      req.input(key, val.type, val.value);
    } else {
      req.input(key, val);
    }
  }
  return req.query(sqlText);
}

// Gọi Stored Procedure
async function exec(spName, params = {}) {
  const p   = await getPool();
  const req = p.request();
  for (const [key, val] of Object.entries(params)) {
    if (val !== null && val !== undefined && typeof val === 'object' && 'type' in val) {
      req.input(key, val.type, val.value);
    } else {
      req.input(key, val);
    }
  }
  return req.execute(spName);
}

// Kiểm tra kết nối
async function connectDB() {
  try {
    await getPool();
    const r = await query('SELECT COUNT(*) AS cnt FROM dbo.TaiKhoan');
    console.log(`✅ Database sẵn sàng — ${r.recordset[0].cnt} tài khoản`);
  } catch (err) {
    console.error('❌ Lỗi kết nối SQL Server:', err.message);
    console.error('   → Kiểm tra DB_SERVER, DB_USER, DB_PASSWORD trong .env');
    process.exit(1);
  }
}

module.exports = { sql, query, exec, getPool, connectDB };
